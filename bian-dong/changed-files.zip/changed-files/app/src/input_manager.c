#include "input_manager.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <SDL3/SDL.h>

#include "android/input.h"
#include "android/keycodes.h"
#include "events.h"
#include "input_events.h"
#include "mapping_manager.h"
#include "overlay_ui.h"
#include "screen.h"
#include "shortcut_mod.h"
#include "util/log.h"
#include "util/sdl.h"

// ==================== 辅助函数 ====================

static struct sc_mapping_manager *
mm_of(struct sc_input_manager *im) {
    return &im->screen->mm;
}

static struct sc_overlay *
ov_of(struct sc_input_manager *im) {
    return &im->screen->overlay;
}

// Send a touch at a normalized position (nx, ny in [0,1])
// Positions are converted with the *current* frame_size on every injection,
// so rotations / --max-size / --crop keep working (the server's PositionMapper
// compares the sent screen size against the current video size).
static bool
inject_touch_norm_once(struct sc_input_manager *im,
                       enum android_motionevent_action action,
                       double nx, double ny, int32_t pointer_id) {
    if (!im->controller) {
        return true; // teardown: nothing to inject
    }
    struct sc_screen *screen = im->screen;
    int32_t x = (int32_t)(nx * screen->frame_size.width);
    int32_t y = (int32_t)(ny * screen->frame_size.height);
    if (x < 0) x = 0;
    if (y < 0) y = 0;

    bool up = action == AMOTION_EVENT_ACTION_UP;

    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_INJECT_TOUCH_EVENT;
    msg.inject_touch_event.action = action;
    msg.inject_touch_event.position.screen_size = screen->frame_size;
    msg.inject_touch_event.position.point.x = x;
    msg.inject_touch_event.position.point.y = y;
    msg.inject_touch_event.pointer_id = pointer_id;
    msg.inject_touch_event.pressure = up ? 0.0f : 1.0f;
    msg.inject_touch_event.action_button = 0;
    msg.inject_touch_event.buttons = 0;

    return sc_controller_push_msg(im->controller, &msg);
}

// ACTION_DOWN / ACTION_UP must never be lost: the server allocates a pointer
// slot per id and only frees it on UP, so a dropped UP leaks a slot forever
// (MAX_POINTERS = 10, then every touch is refused). MOVE is droppable, DOWN and
// UP are retried.
static bool
inject_touch_norm(struct sc_input_manager *im,
                  enum android_motionevent_action action,
                  double nx, double ny, int32_t pointer_id) {
    bool critical = action == AMOTION_EVENT_ACTION_DOWN
                 || action == AMOTION_EVENT_ACTION_UP;
    int attempts = critical ? 3 : 1;
    for (int i = 0; i < attempts; i++) {
        if (inject_touch_norm_once(im, action, nx, ny, pointer_id)) {
            return true;
        }
        if (i + 1 < attempts) {
            SDL_Delay(5);
        }
    }
    if (critical) {
        LOGE("Could not inject %s for pointer %d (3 attempts)",
             action == AMOTION_EVENT_ACTION_UP ? "UP" : "DOWN",
             (int) pointer_id);
    }
    return false;
}

// Inject a touch for a mapping entry (uses its normalized coords). For
// multi-position entries every finger is pressed / lifted at once.
static bool
inject_entry(struct sc_input_manager *im, struct sc_mapping_entry *e,
             enum android_motionevent_action action) {
    bool ok = inject_touch_norm(im, action, e->nx, e->ny, e->pointer_id);
    for (int p = 0; p < e->npositions - 1; p++) {
        if (!inject_touch_norm(im, action, e->extra_nx[p], e->extra_ny[p],
                               e->extra_pid[p])) {
            ok = false;
        }
    }
    return ok;
}

// ==================== 滑动（hold-to-slide） ====================

// Rate limits: a slide must not be able to flood the control queue, and a
// 0-delay configuration is meaningless (4 ms is the floor).
#define SLIDE_STEPS_DEFAULT 20
#define SLIDE_STEPS_MIN 2
#define SLIDE_STEPS_MAX 120
#define SLIDE_STEP_MIN_MS 4
#define SLIDE_DURATION_MIN_MS 50
#define SLIDE_DURATION_MAX_MS 5000

static void
slide_stop_all(struct sc_input_manager *im);

static void
motion_stop(struct sc_input_manager *im);

static void
motion_set_capture(struct sc_input_manager *im, bool on);

static bool
dep_ok(struct sc_input_manager *im, struct sc_mapping_entry *e);

static bool
slide_start(struct sc_input_manager *im, struct sc_mapping_entry *e);

static void
slide_stop_for_entry(struct sc_input_manager *im, struct sc_mapping_entry *e);

static double
clamp01(double v) {
    if (v < 0.0) return 0.0;
    if (v > 1.0) return 1.0;
    return v;
}

static bool
slide_start(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    int slot = -1;
    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        if (!im->slides[i].active) {
            slot = i;
            break;
        }
    }
    if (slot < 0) {
        LOGW("Too many concurrent slides (max %d), '%s' ignored",
             SC_MAX_SLIDES, e->key_name);
        return false;
    }

    int duration_ms = e->duration_ms > 0 ? e->duration_ms : 200;
    if (duration_ms < SLIDE_DURATION_MIN_MS) {
        LOGW("Slide '%s': duration_ms %d < %d, clamped", e->key_name,
             duration_ms, SLIDE_DURATION_MIN_MS);
        duration_ms = SLIDE_DURATION_MIN_MS;
    } else if (duration_ms > SLIDE_DURATION_MAX_MS) {
        LOGW("Slide '%s': duration_ms %d > %d, clamped", e->key_name,
             duration_ms, SLIDE_DURATION_MAX_MS);
        duration_ms = SLIDE_DURATION_MAX_MS;
    }

    int steps = SLIDE_STEPS_DEFAULT;
    int step_ms = duration_ms / steps;
    if (step_ms < SLIDE_STEP_MIN_MS) {
        LOGW("Slide '%s': %d steps in %d ms needs <%d ms per step, "
             "using %d ms", e->key_name, steps, duration_ms,
             SLIDE_STEP_MIN_MS, SLIDE_STEP_MIN_MS);
        step_ms = SLIDE_STEP_MIN_MS;
        steps = duration_ms / step_ms;
    }
    if (steps < SLIDE_STEPS_MIN) steps = SLIDE_STEPS_MIN;
    if (steps > SLIDE_STEPS_MAX) steps = SLIDE_STEPS_MAX;

    struct sc_slide_run *r = &im->slides[slot];
    // Value copy only: a later reload may replace the entry (and the whole
    // entry table), the run must not reference it.
    r->active = true;
    r->pointer_id = e->pointer_id;
    r->nx = e->nx;
    r->ny = e->ny;
    r->ndx = e->ndx;
    r->ndy = e->ndy;
    r->cur_nx = e->nx;
    r->cur_ny = e->ny;
    r->steps = steps;
    r->step_ms = step_ms;
    r->step = 0;
    r->start = sc_tick_now();

    if (!inject_touch_norm(im, AMOTION_EVENT_ACTION_DOWN, r->nx, r->ny,
                           r->pointer_id)) {
        r->active = false;
        return false;
    }
    return true;
}

static void
slide_stop(struct sc_input_manager *im, struct sc_slide_run *r) {
    if (!r->active) return;
    // The segment is closed with an UP at the current point. A single MOVE
    // jumping back to the start would be seen by the device as a very fast
    // stroke in the opposite direction (a "fling"), so the next segment is
    // opened with a fresh DOWN at the start point instead.
    if (!inject_touch_norm(im, AMOTION_EVENT_ACTION_UP, r->cur_nx, r->cur_ny,
                           r->pointer_id)) {
        LOGE("Slide UP could not be injected for pointer %d",
             (int) r->pointer_id);
    }
    r->active = false;
}

static void
slide_stop_for_entry(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        struct sc_slide_run *r = &im->slides[i];
        if (r->active && r->pointer_id == e->pointer_id) {
            slide_stop(im, r);
        }
    }
}

static void
slide_stop_all(struct sc_input_manager *im) {
    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        if (im->slides[i].active) {
            slide_stop(im, &im->slides[i]);
        }
    }
}

// Advance running slides from the event loop. No thread is detached: the
// progression is driven by sc_tick_now(), so there is nothing to join and
// nothing can outlive the controller.
void
sc_input_manager_tick(struct sc_input_manager *im) {
    struct sc_mapping_manager *mm = mm_of(im);
    bool blocked = im->screen->paused || im->disconnected || !im->controller
                || !mm->enabled;

    // Motion is not time driven, but it must be lifted as soon as the mapping
    // becomes invalid (pause, disconnect, disable, teardown).
    if (im->motion.active && blocked) {
        motion_stop(im);
    }

    bool any = false;
    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        if (im->slides[i].active) {
            any = true;
            break;
        }
    }
    if (!any) return; // cheap fast path: tick runs on every event

    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        struct sc_slide_run *r = &im->slides[i];
        if (!r->active) continue;
        if (blocked) {
            slide_stop(im, r);
            continue;
        }

        sc_tick elapsed = sc_tick_now() - r->start;
        int desired = (int) (elapsed / SC_TICK_FROM_MS(r->step_ms));
        if (desired > r->steps) desired = r->steps;
        if (desired <= r->step) continue;

        // Only the newest position is sent (intermediate steps are skipped
        // rather than queued), which keeps the control queue out of trouble.
        double t = (double) desired / (double) r->steps;
        r->cur_nx = clamp01(r->nx + r->ndx * t);
        r->cur_ny = clamp01(r->ny + r->ndy * t);
        r->step = desired;
        inject_touch_norm(im, AMOTION_EVENT_ACTION_MOVE, r->cur_nx, r->cur_ny,
                          r->pointer_id);

        if (desired >= r->steps) {
            // Segment finished. Close it with UP at the end point and reopen
            // at the start with a DOWN (holding the key keeps sliding).
            slide_stop(im, r);

            struct sc_mapping_entry *e = NULL;
            for (int k = 0; k < SC_MAPPING_MAX_ENTRIES; k++) {
                if (mm->entries[k].key_name && mm->entries[k].down
                        && mm->entries[k].pointer_id == r->pointer_id) {
                    e = &mm->entries[k];
                    break;
                }
            }
            if (e) {
                slide_start(im, e);
            }
        }
    }
}

// ==================== 鼠标位移映射（motion） ====================

// A MOVE is droppable and the control queue holds 60 messages, so motion is
// throttled instead of flooding: at most one injected MOVE every 8 ms. Deltas
// received in between are accumulated and applied on the next injection, so
// the total displacement still matches the mouse movement.
#define MOTION_MIN_INTERVAL_MS 8

static struct sc_mapping_entry *
find_motion_entry(struct sc_mapping_manager *mm) {
    for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; i++) {
        if (mm->entries[i].key_name
                && mm->entries[i].type == SC_MAPPING_TYPE_MOTION) {
            return &mm->entries[i];
        }
    }
    return NULL;
}

static bool
motion_any_button_down(struct sc_input_manager *im) {
    for (int b = 1; b <= 5; b++) {
        if (im->map_mouse_down[b]) return true;
    }
    return false;
}

// Engage/release SDL relative mouse mode for the duration of a motion swipe.
// Relative mode hides the OS cursor and keeps reporting xrel past the screen
// edge, which is what lets a swipe (especially look mode) rotate forever;
// without it the cursor runs into the monitor edge and xrel simply stops. It
// is released the moment the finger lifts so normal absolute input resumes.
static void
motion_set_capture(struct sc_input_manager *im, bool on) {
    struct sc_motion_run *r = &im->motion;
    if (r->capture_active == on) {
        return;
    }
    SDL_Window *window = im->screen ? im->screen->window : NULL;
    if (!window) {
        return;
    }
    if (!SDL_SetWindowRelativeMouseMode(window, on)) {
        LOGE("Could not set relative mouse mode to %s: %s",
             on ? "true" : "false", SDL_GetError());
        return;
    }
    r->capture_active = on;
    if (on) {
        // Entering relative mode recenters the cursor; the next motion event
        // reports that jump as a delta. Drop it so the finger does not lurch.
        r->discard_next = true;
        r->pend_nx = 0.0;
        r->pend_ny = 0.0;
    } else {
        r->discard_next = false;
    }
}

static void
motion_stop(struct sc_input_manager *im) {
    motion_set_capture(im, false); // always restore the cursor, even on teardown
    if (!im->motion.active) return;
    // Close the swipe with an UP at the last injected point. There is no
    // teleport back to the anchor: a single MOVE across the screen would be
    // read as a fast stroke in the opposite direction.
    inject_touch_norm(im, AMOTION_EVENT_ACTION_UP, im->motion.cur_nx,
                      im->motion.cur_ny, im->motion.pointer_id);
    im->motion.active = false;
    struct sc_mapping_entry *e = find_motion_entry(mm_of(im));
    if (e && e->pointer_id == im->motion.pointer_id) {
        e->active = false;
        e->down = false;
    }
}

static void
motion_start(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    struct sc_motion_run *r = &im->motion;
    r->active = true;
    r->pointer_id = e->pointer_id;
    r->anchor_nx = e->nx;
    r->anchor_ny = e->ny;
    r->cur_nx = e->nx;
    r->cur_ny = e->ny;
    r->sensitivity = e->sensitivity > 0.0
        ? e->sensitivity : SC_MAPPING_SENSITIVITY_DEFAULT;
    r->pend_nx = 0.0;
    r->pend_ny = 0.0;
    r->last_inject = sc_tick_now();
    e->active = true;
    e->down = true;
    if (!inject_touch_norm(im, AMOTION_EVENT_ACTION_DOWN, r->cur_nx, r->cur_ny,
                           r->pointer_id)) {
        r->active = false;
        e->active = false;
        e->down = false;
        return;
    }
    // DOWN succeeded: hide and confine the OS cursor so it never hits the
    // screen edge and keeps feeding xrel for the whole swipe. The recenter
    // jump is dropped in motion_feed().
    motion_set_capture(im, true);
}

// Convert the mouse delta of one event into the movement of the synthetic
// finger. Returns true when the event was consumed by the motion mapping:
// either it is actively driving the finger, or a motion entry exists while a
// mouse button is held (in that case the physical pointer must not be forwarded
// at the same time, otherwise two pointers move the device cursor at once).
static bool
motion_feed(struct sc_input_manager *im, float xrel, float yrel) {
    struct sc_mapping_manager *mm = mm_of(im);
    struct sc_mapping_entry *e = find_motion_entry(mm);
    bool latched = e && e->hold == SC_MOTION_HOLD_ALWAYS;
    bool engaged = e && mm->enabled && im->controller
                && !im->screen->paused && !im->disconnected
                && !im->design_mode && !im->switch_open
                && (latched || motion_any_button_down(im));
    if (!engaged || !dep_ok(im, e)) {
        motion_stop(im);
        return false;
    }

    // Read the *current* frame size: rotation, --max-size and --crop all
    // change it at runtime and the server drops MOVEs sized with a stale one.
    int fw = im->screen->frame_size.width;
    int fh = im->screen->frame_size.height;
    if (fw <= 0 || fh <= 0) return true;

    if (!im->motion.active) {
        motion_start(im, e);
        if (!im->motion.active) return true;
        // This event's delta was produced before the cursor was recentered,
        // so it is a genuine user movement and is applied normally below.
    } else if (im->motion.discard_next) {
        // This event reports the recenter jump caused by entering relative
        // mouse mode; drop it so the finger does not lurch across the screen.
        im->motion.discard_next = false;
        im->motion.pend_nx = 0.0;
        im->motion.pend_ny = 0.0;
        // #region debug-point D:capture-delta-discarded
        LOGW("[DEBUG] sessionId=mapping-input-stalls runId=pre-fix "
             "hypothesisId=D location=input_manager.c:motion_feed "
             "msg=capture-delta-discarded now=%" PRItick " xrel=%f yrel=%f",
             sc_tick_now(), (double) xrel, (double) yrel);
        // #endregion
        return true;
    }

    im->motion.pend_nx += (double) xrel * im->motion.sensitivity / (double) fw;
    im->motion.pend_ny += (double) yrel * im->motion.sensitivity / (double) fh;
    if (sc_tick_now() - im->motion.last_inject
            < SC_TICK_FROM_MS(MOTION_MIN_INTERVAL_MS)) {
        return true; // keep accumulating, the next event injects the sum
    }
    double dnx = im->motion.pend_nx;
    double dny = im->motion.pend_ny;
    im->motion.pend_nx = 0.0;
    im->motion.pend_ny = 0.0;
    // #region debug-point B:motion-injection-attempt
    static unsigned debug_injection_seq;
    if ((++debug_injection_seq & 15) == 0) {
        LOGW("[DEBUG] sessionId=mapping-input-stalls runId=pre-fix "
             "hypothesisId=B location=input_manager.c:motion_feed "
             "msg=motion-injection-sample now=%" PRItick
             " interval_us=%" PRItick " dnx=%f dny=%f",
             sc_tick_now(),
             SC_TICK_TO_US(sc_tick_now() - im->motion.last_inject), dnx, dny);
    }
    // #endregion
    im->motion.last_inject = sc_tick_now();

    double tx = im->motion.cur_nx + dnx;
    double ty = im->motion.cur_ny + dny;

    if (tx < 0.0 || tx > 1.0 || ty < 0.0 || ty > 1.0) {
        // Boundary wrap (applies to both button and look modes): move to the
        // clamped edge, close the stroke there with an UP, then reopen it at
        // the anchor with a DOWN and keep sliding in the same direction. This
        // mirrors the slide type (see sc_input_manager_tick), which feels
        // smooth. A single MOVE teleporting back to the anchor would be read as
        // a fast reverse stroke and yank the view back, so it is deliberately
        // avoided; the cost is one UP/DOWN pair per wrap, with no dead zone in
        // either direction afterwards.
        double ex = clamp01(tx);
        double ey = clamp01(ty);
        // #region debug-point D:motion-wrap
        LOGW("[DEBUG] sessionId=mapping-input-stalls runId=pre-fix "
             "hypothesisId=D location=input_manager.c:motion_feed "
             "msg=motion-wrap now=%" PRItick " ex=%f ey=%f dnx=%f dny=%f",
             sc_tick_now(), ex, ey, dnx, dny);
        // #endregion
        inject_touch_norm(im, AMOTION_EVENT_ACTION_MOVE, ex, ey,
                          im->motion.pointer_id);
        inject_touch_norm(im, AMOTION_EVENT_ACTION_UP, ex, ey,
                          im->motion.pointer_id);
        im->motion.cur_nx = im->motion.anchor_nx;
        im->motion.cur_ny = im->motion.anchor_ny;
        inject_touch_norm(im, AMOTION_EVENT_ACTION_DOWN, im->motion.cur_nx,
                          im->motion.cur_ny, im->motion.pointer_id);
        return true;
    }

    im->motion.cur_nx = tx;
    im->motion.cur_ny = ty;
    inject_touch_norm(im, AMOTION_EVENT_ACTION_MOVE, tx, ty,
                      im->motion.pointer_id);
    return true;
}

// ==================== 映射激活 / 依赖 ====================

// Render the dependency conditions of an entry for log messages, e.g.
// "lshift pressed" or "flag:look_mode on".
static void
dep_conds_to_name_log(const struct sc_mapping_entry *e, char *buf,
                      size_t buflen) {
    buf[0] = '\0';
    if (!e || e->ndeps <= 0 || buflen == 0) {
        return;
    }
    size_t off = 0;
    for (int i = 0; i < e->ndeps; i++) {
        char name[128];
        sc_cond_to_name(&e->deps[i], name, sizeof(name));
        int n = snprintf(buf + off, buflen - off, "%s%s %s",
                         i > 0 ? ", " : "", name,
                         sc_cond_state_name(&e->deps[i]));
        if (n < 0) {
            break;
        }
        off += (size_t) n;
        if (off >= buflen - 1) {
            break;
        }
    }
    buf[off] = '\0';
}

static bool
key_held(struct sc_input_manager *im, SDL_Keycode kc) {
    // A virtual single-key entry exposes its logical state (momentary follows
    // the physical key; toggle holds the flipped state) so other entries can
    // depend on it even while no touch is injected.
    struct sc_mapping_entry *v =
        sc_mapping_manager_find_single(mm_of(im), kc);
    if (v && v->is_virtual) {
        return v->down;
    }
    if (SC_MAPPING_KEYCODE_IS_MOUSE(kc)) {
        int button = SC_MAPPING_KEYCODE_MOUSE_BUTTON(kc);
        return button >= 1 && button <= 5 && im->map_mouse_down[button];
    }
    return im->g_pressed[kc & 0xFF];
}

// Evaluate the *source* of a dependency condition: true when the source is
// "on". A key source is on when it is held (a combo is on when every member
// is held), an entry source is on when the referenced entry is logically
// active, a flag source is on when the registered feature flag is set.
static bool
cond_source_on(struct sc_input_manager *im,
               const struct sc_mapping_cond *c) {
    if (!c) {
        return false;
    }
    switch (c->kind) {
        case SC_COND_KIND_KEY:
            for (int i = 0; i < c->nkeys; i++) {
                if (!key_held(im, c->keys[i])) {
                    return false;
                }
            }
            return c->nkeys > 0;
        case SC_COND_KIND_ENTRY: {
            // The referenced entry may have been replaced by a hot-reload, so
            // it is looked up by name every time.
            struct sc_mapping_entry *t =
                sc_mapping_manager_find_by_name(mm_of(im), c->name);
            if (!t) {
                return false;
            }
            // "down" is the logical state (momentary: held, toggle: flipped),
            // "active" covers the entries whose injection is running.
            return t->down || t->active;
        }
        case SC_COND_KIND_FLAG: {
            const struct sc_cond_flag_def *d = sc_cond_flag_find(c->name);
            if (!d || !d->fn) {
                return false;
            }
            return d->fn(sc_cond_flag_ctx());
        }
    }
    return false;
}

// True when every dependency condition of the entry is satisfied.
static bool
dep_ok(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    if (!e) {
        return true;
    }
    for (int i = 0; i < e->ndeps; i++) {
        bool on = cond_source_on(im, &e->deps[i]);
        if (e->deps[i].state == SC_COND_STATE_ON) {
            if (!on) {
                return false;
            }
        } else if (on) {
            return false;
        }
    }
    return true;
}

// Physical state of the entry's own trigger (mouse buttons included).
static bool
entry_trigger_held(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    if (e->nkeys == 1) {
        return key_held(im, e->keys[0]);
    }
    return e->active; // combos: driven by update_combos()
}

static void
entry_activate(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    if (!e || e->active) return;
    if (!dep_ok(im, e)) {
        char depname[160] = "?";
        dep_conds_to_name_log(e, depname, sizeof(depname));
        LOGI("Mapping '%s' not entered: dependency '%s' is not satisfied",
             e->key_name, depname);
        return;
    }
    e->active = true;
    e->down = true;
    // Virtual keys never inject: they only carry logical state.
    if (e->is_virtual) return;
    if (e->type == SC_MAPPING_TYPE_SLIDE) {
        if (!slide_start(im, e)) {
            // Could not open a slide slot / inject the DOWN: report it as
            // released so nothing is left marked as pressed.
            e->active = false;
            e->down = false;
        }
    } else {
        inject_entry(im, e, AMOTION_EVENT_ACTION_DOWN);
    }
}

static void
entry_deactivate(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    if (!e) return;
    bool was = e->active || e->down;
    e->active = false;
    e->down = false;
    if (e->is_virtual) return; // nothing to lift
    if (e->type == SC_MAPPING_TYPE_SLIDE) {
        slide_stop_for_entry(im, e);
    } else if (e->type == SC_MAPPING_TYPE_MOTION) {
        motion_stop(im);
    } else if (was) {
        // UP is always sent at most once per activation: `was` guards against
        // a second UP for an entry that was only marked as down.
        inject_entry(im, e, AMOTION_EVENT_ACTION_UP);
    }
}

// Re-evaluate every dependency after a key/button state change. This is what
// makes "dependency satisfied" and "dependency lost" enter/exit the mapping
// without ever dropping the UP.
static void
evaluate_dependencies(struct sc_input_manager *im) {
    struct sc_mapping_manager *mm = mm_of(im);
    for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; i++) {
        struct sc_mapping_entry *e = &mm->entries[i];
        if (!e->key_name || e->ndeps == 0) continue;
        if (e->nkeys >= 2) continue; // combos: handled inside update_combos()
        if (!dep_ok(im, e)) {
            if (e->active || e->down) {
                entry_deactivate(im, e);
                LOGI("Mapping '%s' released: dependency lost", e->key_name);
            }
            continue;
        }
        // Momentary mappings re-enter while their trigger is still held;
        // toggles wait for the next explicit press edge.
        if (e->mode == SC_MAPPING_MODE_MOMENTARY && !e->active
                && entry_trigger_held(im, e)) {
            entry_activate(im, e);
            LOGI("Mapping '%s' entered: dependency satisfied", e->key_name);
        }
    }
}

// Lift every held entry (combos and single keys). Called before any state that
// invalidates the entries (hot-reload, template switch, disable, destroy).
static void
mapping_release_all(void *userdata) {
    struct sc_input_manager *im = userdata;
    struct sc_mapping_manager *mm = mm_of(im);

    // Running motion / slides must be stopped (and their UP injected) before
    // the entries they were derived from are replaced.
    motion_stop(im);
    slide_stop_all(im);

    for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; i++) {
        struct sc_mapping_entry *e = &mm->entries[i];
        if (!e->key_name) continue;
        bool was = e->active || e->down;
        e->active = false;
        e->down = false;
        // Virtual keys never injected a touch; slides already sent their UP
        // through slide_stop_all(); motion entries never own an entry-level DOWN.
        if (was && e->type == SC_MAPPING_TYPE_TOUCH && !e->is_virtual) {
            inject_entry(im, e, AMOTION_EVENT_ACTION_UP);
        }
    }
    memset(im->g_pressed, 0, sizeof(im->g_pressed));
    memset(im->map_mouse_down, 0, sizeof(im->map_mouse_down));
    im->left_click_locked_down = false;
}

// Update all combos based on currently pressed keys
static void
update_combos(struct sc_input_manager *im) {
    struct sc_mapping_manager *mm = mm_of(im);
    for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; ++i) {
        struct sc_mapping_entry *c = &mm->entries[i];
        if (!c->key_name || c->nkeys < 2) continue;

        bool match = true;
        for (int j = 0; j < c->nkeys; ++j) {
            if (!im->g_pressed[c->keys[j] & 0xFF]) {
                match = false;
                break;
            }
        }
        if (match && !dep_ok(im, c)) {
            match = false;
        }

        if (match && !c->active) {
            // Release single-key downs for combo members
            for (int j = 0; j < c->nkeys; ++j) {
                struct sc_mapping_entry *m =
                    sc_mapping_manager_find_single(mm, c->keys[j]);
                if (m && (m->down || m->active)) {
                    entry_deactivate(im, m);
                }
            }
            c->active = true;
            if (!c->is_virtual) {
                inject_entry(im, c, AMOTION_EVENT_ACTION_DOWN);
            }
            LOGI("Combo down: %s%s", c->key_name,
                 c->is_virtual ? " (virtual)" : "");
        } else if (!match && c->active) {
            c->active = false;
            if (!c->is_virtual) {
                inject_entry(im, c, AMOTION_EVENT_ACTION_UP);
            }
            LOGI("Combo up: %s", c->key_name);
            // Re-press single keys still held (entry_activate re-checks the
            // dependency condition)
            for (int j = 0; j < c->nkeys; ++j) {
                if (!im->g_pressed[c->keys[j] & 0xFF]) continue;
                struct sc_mapping_entry *m =
                    sc_mapping_manager_find_single(mm, c->keys[j]);
                // Slides are never combo members (rejected at load time)
                if (m && !m->active && m->type != SC_MAPPING_TYPE_SLIDE) {
                    entry_activate(im, m);
                }
            }
        }
    }
}

// ==================== 模板切换弹窗 ====================

static void
open_template_switch(struct sc_input_manager *im) {
    struct sc_mapping_manager *mm = mm_of(im);
    struct sc_overlay *ov = ov_of(im);

    char **names = NULL;
    int total = sc_mapping_manager_list(mm, NULL, 0);
    if (total <= 0) {
        sc_overlay_set_status(ov, "No templates found");
        return;
    }
    names = calloc((size_t)total, sizeof(char *));
    if (!names) return;
    sc_mapping_manager_list(mm, names, total);

    // F2 picker and F3 design mode are mutually exclusive: only one overlay may
    // be live at a time.
    if (im->design_mode) {
        im->design_mode = false;
        sc_mapping_manager_design_reset(mm);
        sc_mapping_manager_save_active(mm); // dirty-gated
        sc_overlay_set_design(ov, false, NULL);
        LOGI("Design mode OFF (template picker opened)");
    }

    sc_overlay_show_switch(ov, names, total);
    im->switch_open = true;
}

static void
close_template_switch(struct sc_input_manager *im) {
    if (im->switch_open) {
        sc_overlay_hide_switch(ov_of(im));
        im->switch_open = false;
    }
}

// ==================== 设计模式 ====================

static void
toggle_design_mode(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    im->design_mode = !im->design_mode;
    if (im->design_mode) {
        close_template_switch(im); // never two overlays at once
        motion_stop(im);           // no synthetic swipe while picking points
        sc_mapping_manager_design_reset(mm_of(im));
        sc_overlay_set_design(ov, true,
            "Design: click position, then press a key. F3 to exit.");
        LOGI("Design mode ON");
    } else {
        // Save only if something actually changed (dirty flag), never blindly
        sc_mapping_manager_design_reset(mm_of(im));
        if (sc_mapping_manager_save_active(mm_of(im))) {
            sc_overlay_set_status(ov, "Design mode off");
        }
        sc_overlay_set_design(ov, false, NULL);
        LOGI("Design mode OFF");
    }
}

// ==================== 内置管理面板（F5） ====================

// The panel edits the live entry table through the same validation functions
// used by the JSON loader (sc_mapping_manager_upsert /
// sc_mapping_validate_key_expr), so the editor and the loader cannot disagree.

static int
entry_index_by_sel(struct sc_mapping_manager *mm, int sel) {
    int n = 0;
    for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; i++) {
        if (!mm->entries[i].key_name) continue;
        if (n == sel) return i;
        n++;
    }
    return -1;
}

static struct sc_mapping_entry *
manager_selected_entry(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    int idx = entry_index_by_sel(mm_of(im), ov->mgr_entry_sel);
    return idx >= 0 ? &mm_of(im)->entries[idx] : NULL;
}

// Update one entry through the same validator as the JSON loader, keeping the
// fields the caller does not change (mode, dependency, sensitivity). Without
// this the panel would silently reset the new optional fields on every edit.
static bool
manager_apply(struct sc_input_manager *im, struct sc_mapping_entry *e,
              double nx, double ny, double ndx, double ndy, int duration_ms,
              enum sc_mapping_mode mode,
              const struct sc_mapping_cond *deps, int ndeps,
              double sensitivity, enum sc_motion_hold hold, char *err,
              size_t errlen) {
    return sc_mapping_manager_upsert_ex(mm_of(im), e->key_name, e->type,
                                        nx, ny, ndx, ndy, duration_ms, mode,
                                        deps, ndeps, sensitivity, hold,
                                        e->is_virtual, err, errlen);
}

// Replace the dependency conditions of an entry with a single key condition.
static void
manager_set_dep(struct sc_input_manager *im, struct sc_mapping_entry *e,
                SDL_Keycode dep_key, enum sc_mapping_cond_state state) {
    struct sc_overlay *ov = ov_of(im);
    char err[128];
    struct sc_mapping_cond cond;
    memset(&cond, 0, sizeof(cond));
    sc_cond_init_key(&cond, dep_key, state);
    if (!manager_apply(im, e, e->nx, e->ny, e->ndx, e->ndy, e->duration_ms,
                       e->mode, &cond, 1, e->sensitivity, e->hold,
                       err, sizeof(err))) {
        char msg[192];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager dependency rejected: %s", err);
        return;
    }
    char msg[128];
    snprintf(msg, sizeof(msg), "Depends on %s %s (press S to save)",
             sc_mapping_key_name(dep_key),
             state == SC_COND_STATE_OFF ? "released" : "pressed");
    sc_overlay_manager_set_hint(ov, msg);
}

// Replace the dependency conditions of an entry with a single built-in
// feature flag condition.
static void
manager_set_flag_dep(struct sc_input_manager *im, struct sc_mapping_entry *e,
                     const char *name, enum sc_mapping_cond_state state) {
    struct sc_overlay *ov = ov_of(im);
    char err[128];
    struct sc_mapping_cond cond;
    memset(&cond, 0, sizeof(cond));
    cond.kind = SC_COND_KIND_FLAG;
    cond.state = state;
    snprintf(cond.name, sizeof(cond.name), "%s", name);
    if (!manager_apply(im, e, e->nx, e->ny, e->ndx, e->ndy, e->duration_ms,
                       e->mode, &cond, 1, e->sensitivity, e->hold,
                       err, sizeof(err))) {
        char msg[192];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager dependency rejected: %s", err);
        return;
    }
    char msg[192];
    snprintf(msg, sizeof(msg), "Depends on flag:%s %s (press S to save)", name,
             state == SC_COND_STATE_OFF ? "off" : "on");
    sc_overlay_manager_set_hint(ov, msg);
}

// G cycles through the registered built-in features and makes the selected
// one the dependency of the entry.
static void
manager_cycle_flag_dep(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    int count = sc_cond_flag_count();
    if (count <= 0) {
        sc_overlay_manager_set_hint(ov, "No built-in feature registered");
        return;
    }
    // Continue after the flag that is currently used, or start at the first.
    int next = 0;
    if (e->ndeps > 0 && e->deps[0].kind == SC_COND_KIND_FLAG) {
        for (int i = 0; i < count; i++) {
            const struct sc_cond_flag_def *d = sc_cond_flag_at(i);
            if (d && !strcmp(d->name, e->deps[0].name)) {
                next = (i + 1) % count;
                break;
            }
        }
    }
    const struct sc_cond_flag_def *d = sc_cond_flag_at(next);
    if (!d) {
        sc_overlay_manager_set_hint(ov, "No built-in feature registered");
        return;
    }
    manager_set_flag_dep(im, e, d->name, SC_COND_STATE_ON);
    char msg[256];
    snprintf(msg, sizeof(msg), "flag %d/%d: %s - %s", next + 1, count, d->name,
             d->desc);
    sc_overlay_manager_set_hint(ov, msg);
}

// Clear every dependency condition of an entry.
static void
manager_clear_dep(struct sc_input_manager *im, struct sc_mapping_entry *e) {
    struct sc_overlay *ov = ov_of(im);
    char err[128];
    if (!manager_apply(im, e, e->nx, e->ny, e->ndx, e->ndy, e->duration_ms,
                       e->mode, NULL, 0, e->sensitivity, e->hold,
                       err, sizeof(err))) {
        char msg[192];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager dependency rejected: %s", err);
        return;
    }
    sc_overlay_manager_set_hint(ov, "Dependency cleared (press S to save)");
}

static void
manager_refresh_templates(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);
    int total = sc_mapping_manager_list(mm, NULL, 0);
    char **names = NULL;
    if (total > 0) {
        names = calloc((size_t) total, sizeof(char *));
        if (names) {
            sc_mapping_manager_list(mm, names, total);
        } else {
            total = 0;
        }
    }
    free(ov->mgr_names);
    ov->mgr_names = names;
    ov->mgr_count = names ? total : 0;
    if (ov->mgr_tmpl_sel >= ov->mgr_count) {
        ov->mgr_tmpl_sel = ov->mgr_count > 0 ? ov->mgr_count - 1 : 0;
    }
}

static void
manager_open(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);

    // F3 and F5 are mutually exclusive
    if (im->design_mode) {
        im->design_mode = false;
        sc_overlay_set_design(ov, false, NULL);
    }
    if (im->switch_open) {
        close_template_switch(im);
    }
    // Entering the panel restores all input state (no finger left down)
    mapping_release_all(im);

    sc_overlay_set_manager(ov, true, mm, NULL, 0);
    manager_refresh_templates(im);

    ov->mgr_focus = 1;
    ov->mgr_entry_sel = 0;
    for (int i = 0; i < ov->mgr_count; i++) {
        if (mm->active_name && ov->mgr_names[i]
                && strcmp(mm->active_name, ov->mgr_names[i]) == 0) {
            ov->mgr_tmpl_sel = i;
            break;
        }
    }
    sc_overlay_manager_set_hint(ov,
        "1-6 edit field, Enter commit, N new, V motion, M mode, D depend, "
        "G feature");
    LOGI("Manager panel opened");
}

static void
manager_close(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);

    sc_overlay_set_manager(ov, false, NULL, NULL, 0);
    // Restore every bit of input state the panel may have touched
    mapping_release_all(im);
    im->left_click_locked_down = false;
    // Dirty-gated: nothing is written when nothing was modified
    sc_mapping_manager_save_active(mm);
    LOGI("Manager panel closed");
}

static void
manager_begin_edit(struct sc_input_manager *im, int field) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    if (field >= 2 && field <= 4 && e->type != SC_MAPPING_TYPE_SLIDE) {
        sc_overlay_manager_set_hint(ov,
            "dx/dy/duration need a slide entry (press T)");
        return;
    }
    if (field == 5 && e->type != SC_MAPPING_TYPE_MOTION) {
        sc_overlay_manager_set_hint(ov,
            "sensitivity needs the MOUSE_MOVE motion entry (press V)");
        return;
    }
    ov->mgr_edit_field = field;
    ov->mgr_edit_len = 0;
    ov->mgr_edit_buf[0] = '\0';
    if (field == 0) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                             "%.5f", e->nx);
    else if (field == 1) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                                  "%.5f", e->ny);
    else if (field == 2) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                                  "%.5f", e->ndx);
    else if (field == 3) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                                  "%.5f", e->ndy);
    else if (field == 4) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                                  "%d", e->duration_ms);
    else if (field == 5) snprintf(ov->mgr_edit_buf, sizeof(ov->mgr_edit_buf),
                                  "%.2f", e->sensitivity);
    ov->mgr_edit_len = (int) strlen(ov->mgr_edit_buf);
}

static void
manager_commit_edit(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    int field = ov->mgr_edit_field;
    ov->mgr_edit_field = -1;
    if (!e || field < 0) return;

    double v = atof(ov->mgr_edit_buf);
    double nx = e->nx, ny = e->ny, ndx = e->ndx, ndy = e->ndy;
    int dur = e->duration_ms;
    double sens = e->sensitivity;
    if (field == 0) nx = v;
    else if (field == 1) ny = v;
    else if (field == 2) ndx = v;
    else if (field == 3) ndy = v;
    else if (field == 4) dur = (int) v;
    else if (field == 5) sens = v;

    char err[128];
    if (!manager_apply(im, e, nx, ny, ndx, ndy, dur, e->mode, e->deps,
                       e->ndeps, sens, e->hold,
                       err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager edit rejected: %s", err);
    } else {
        sc_overlay_manager_set_hint(ov, "Updated (not saved yet: press S)");
    }
}

static void
manager_create_entry(struct sc_input_manager *im, const char *key_name) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);

    // Use the last picked point if any, else the frame center
    double nx = 0.5, ny = 0.5;
    if (sc_mapping_manager_design_has_point(mm)) {
        nx = mm->design_nx;
        ny = mm->design_ny;
    }
    char err[128];
    struct sc_mapping_entry *existing =
        sc_mapping_manager_find_by_name(mm, key_name);
    // Re-binding an existing key only moves it: keep mode / dependency /
    // sensitivity instead of resetting them to their defaults.
    bool ok = existing
        ? manager_apply(im, existing, nx, ny, existing->ndx, existing->ndy,
                        existing->duration_ms, existing->mode,
                        existing->deps, existing->ndeps,
                        existing->sensitivity, existing->hold,
                        err, sizeof(err))
        : sc_mapping_manager_upsert(mm, key_name, SC_MAPPING_TYPE_TOUCH,
                                    nx, ny, 0.0, 0.0, 0, err, sizeof(err));
    if (!ok) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager new entry rejected: %s", err);
        return;
    }
    sc_mapping_manager_design_reset(mm);
    manager_refresh_templates(im);
    sc_overlay_manager_set_hint(ov, "Entry added (press S to save)");
}

// Create the reserved MOUSE_MOVE motion entry (there is no key to press for
// it, so the panel needs its own action).
static void
manager_create_motion(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);

    if (sc_mapping_manager_find_by_name(mm, "MOUSE_MOVE")) {
        sc_overlay_manager_set_hint(ov, "MOUSE_MOVE entry already exists");
        return;
    }
    double nx = 0.5, ny = 0.5;
    if (sc_mapping_manager_design_has_point(mm)) {
        nx = mm->design_nx;
        ny = mm->design_ny;
    }
    char err[128];
    if (!sc_mapping_manager_upsert_ex(mm, "MOUSE_MOVE",
                                      SC_MAPPING_TYPE_MOTION, nx, ny,
                                      0.0, 0.0, 0, SC_MAPPING_MODE_MOMENTARY,
                                      NULL, 0,
                                      SC_MAPPING_SENSITIVITY_DEFAULT,
                                      SC_MOTION_HOLD_BUTTON, false,
                                      err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        LOGW("Manager motion entry rejected: %s", err);
        return;
    }
    sc_mapping_manager_design_reset(mm);
    manager_refresh_templates(im);
    sc_overlay_manager_set_hint(ov,
        "MOUSE_MOVE added (edit 6 for sensitivity, S to save)");
}

static void
manager_remove_selected(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    char name[256]; // longest accepted combo is 4 x 63 chars + 3 '+'
    snprintf(name, sizeof(name), "%s", e->key_name);
    if (sc_mapping_manager_remove_entry(mm_of(im), name)) {
        char msg[128];
        snprintf(msg, sizeof(msg), "Removed %s (press S to save)", name);
        sc_overlay_manager_set_hint(ov, msg);
        if (ov->mgr_entry_sel > 0) ov->mgr_entry_sel--;
    }
}

static void
manager_toggle_type(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    if (e->is_mouse) {
        sc_overlay_manager_set_hint(ov, "Mouse entries cannot be slides");
        return;
    }
    if (e->type == SC_MAPPING_TYPE_MOTION) {
        sc_overlay_manager_set_hint(ov,
            "MOUSE_MOVE is always a motion entry");
        return;
    }
    enum sc_mapping_entry_type new_type =
        e->type == SC_MAPPING_TYPE_SLIDE ? SC_MAPPING_TYPE_TOUCH
                                         : SC_MAPPING_TYPE_SLIDE;
    double ndx = e->type == SC_MAPPING_TYPE_SLIDE ? e->ndx : 0.0;
    double ndy = e->type == SC_MAPPING_TYPE_SLIDE ? e->ndy : -0.3;
    int dur = e->type == SC_MAPPING_TYPE_SLIDE ? e->duration_ms : 200;
    // Toggle is only valid for touch entries, so switching to slide drops it.
    enum sc_mapping_mode mode = new_type == SC_MAPPING_TYPE_SLIDE
                             ? SC_MAPPING_MODE_MOMENTARY : e->mode;

    char err[128];
    if (!sc_mapping_manager_upsert_ex(mm_of(im), e->key_name, new_type,
                                      e->nx, e->ny, ndx, ndy, dur, mode,
                                      e->deps, e->ndeps, e->sensitivity,
                                      SC_MOTION_HOLD_BUTTON, e->is_virtual,
                                      err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        return;
    }
    sc_overlay_manager_set_hint(ov, new_type == SC_MAPPING_TYPE_SLIDE
        ? "Now a slide (edit 3/4/5)" : "Now a touch entry");
}

static void
manager_pick_point(struct sc_input_manager *im, double nx, double ny) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    int mode = ov->mgr_pick;
    ov->mgr_pick = 0;

    if (!e) {
        // No entry yet: remember the point for the next "N <key>" creation
        mm_of(im)->design_nx = nx;
        mm_of(im)->design_ny = ny;
        mm_of(im)->design_stage = 1;
        sc_overlay_manager_set_hint(ov, "Point stored: press N then a key");
        return;
    }

    if (mode == 2 && e->type != SC_MAPPING_TYPE_SLIDE) {
        sc_overlay_manager_set_hint(ov, "Press T first to make it a slide");
        return;
    }

    double x = e->nx, y = e->ny, dx = e->ndx, dy = e->ndy;
    if (mode == 1) {
        x = nx;
        y = ny;
    } else {
        // end point of a slide, expressed as a delta from the start
        dx = nx - e->nx;
        dy = ny - e->ny;
    }
    char err[128];
    if (!manager_apply(im, e, x, y, dx, dy, e->duration_ms, e->mode,
                       e->deps, e->ndeps, e->sensitivity,
                       e->hold, err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        return;
    }
    sc_overlay_manager_set_hint(ov, mode == 1 ? "Point updated"
                                              : "Slide end point updated");
}

static void
manager_toggle_mode(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    if (e->type != SC_MAPPING_TYPE_TOUCH || e->nkeys != 1) {
        sc_overlay_manager_set_hint(ov,
            "mode needs a single-key touch entry");
        return;
    }
    enum sc_mapping_mode mode = e->mode == SC_MAPPING_MODE_TOGGLE
                              ? SC_MAPPING_MODE_MOMENTARY
                              : SC_MAPPING_MODE_TOGGLE;
    char err[128];
    if (!manager_apply(im, e, e->nx, e->ny, e->ndx, e->ndy, e->duration_ms,
                       mode, e->deps, e->ndeps,
                       e->sensitivity, e->hold, err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        return;
    }
    sc_overlay_manager_set_hint(ov, mode == SC_MAPPING_MODE_TOGGLE
        ? "Mode: toggle (press S to save)"
        : "Mode: momentary (press S to save)");
}

// H flips the finger lifetime of the MOUSE_MOVE entry:
// button-gated drag <-> latched look mode.
static void
manager_toggle_hold(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    if (e->type != SC_MAPPING_TYPE_MOTION) {
        sc_overlay_manager_set_hint(ov,
            "hold needs the MOUSE_MOVE motion entry (press V)");
        return;
    }
    enum sc_motion_hold hold = e->hold == SC_MOTION_HOLD_ALWAYS
                             ? SC_MOTION_HOLD_BUTTON
                             : SC_MOTION_HOLD_ALWAYS;
    char err[128];
    if (!manager_apply(im, e, e->nx, e->ny, e->ndx, e->ndy, e->duration_ms,
                       e->mode, e->deps, e->ndeps,
                       e->sensitivity, hold, err, sizeof(err))) {
        char msg[160];
        snprintf(msg, sizeof(msg), "Rejected: %s", err);
        sc_overlay_manager_set_hint(ov, msg);
        return;
    }
    sc_overlay_manager_set_hint(ov, hold == SC_MOTION_HOLD_ALWAYS
        ? "Hold: always / look mode (press S to save)"
        : "Hold: while a button is down (press S to save)");
}

// D cycles: no dependency -> capture key (pressed) -> released -> none.
// Only the first condition is edited; the others are kept untouched.
static void
manager_cycle_dep(struct sc_input_manager *im) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_entry *e = manager_selected_entry(im);
    if (!e) {
        sc_overlay_manager_set_hint(ov, "No entry selected");
        return;
    }
    if (e->ndeps == 0) {
        ov->mgr_capture_dep = true;
        sc_overlay_manager_set_hint(ov,
            "Press the dependency key (Esc cancels)");
        return;
    }
    struct sc_mapping_cond first = e->deps[0];
    if (first.kind == SC_COND_KIND_KEY && first.nkeys == 1) {
        // pressed -> released -> none
        if (first.state == SC_COND_STATE_ON) {
            manager_set_dep(im, e, first.keys[0], SC_COND_STATE_OFF);
        } else {
            manager_clear_dep(im, e);
        }
        return;
    }
    if (first.kind == SC_COND_KIND_FLAG) {
        // on -> off -> on
        manager_set_flag_dep(im, e, first.name,
                             first.state == SC_COND_STATE_ON
                                 ? SC_COND_STATE_OFF : SC_COND_STATE_ON);
        return;
    }
    manager_clear_dep(im, e);
}

// Returns true when the key was consumed by the panel.
static bool
manager_handle_key(struct sc_input_manager *im, SDL_Keycode kc) {
    struct sc_overlay *ov = ov_of(im);
    struct sc_mapping_manager *mm = mm_of(im);

    if (ov->mgr_capture_dep) {
        ov->mgr_capture_dep = false;
        struct sc_mapping_entry *e = manager_selected_entry(im);
        if (!e) {
            sc_overlay_manager_set_hint(ov, "No entry selected");
        } else if (kc == SDLK_ESCAPE) {
            sc_overlay_manager_set_hint(ov, "Cancelled");
        } else {
            manager_set_dep(im, e, kc, SC_COND_STATE_ON);
        }
        return true;
    }

    if (ov->mgr_capture_key) {
        ov->mgr_capture_key = false;
        if (kc == SDLK_ESCAPE) {
            sc_overlay_manager_set_hint(ov, "Cancelled");
        } else {
            manager_create_entry(im, sc_mapping_key_name(kc));
        }
        return true;
    }

    if (ov->mgr_edit_field >= 0) {
        if (kc == SDLK_ESCAPE) {
            ov->mgr_edit_field = -1;
            sc_overlay_manager_set_hint(ov, "Edit cancelled");
        } else if (kc == SDLK_RETURN || kc == SDLK_KP_ENTER) {
            manager_commit_edit(im);
        } else if (kc == SDLK_BACKSPACE) {
            if (ov->mgr_edit_len > 0) {
                ov->mgr_edit_buf[--ov->mgr_edit_len] = '\0';
            }
        } else {
            char ch = 0;
            if (kc >= SDLK_0 && kc <= SDLK_9) {
                ch = (char) ('0' + (kc - SDLK_0));
            } else if (kc == SDLK_PERIOD || kc == SDLK_KP_PERIOD) {
                ch = '.';
            } else if (kc == SDLK_MINUS) {
                ch = '-';
            }
            if (ch && ov->mgr_edit_len < (int) sizeof(ov->mgr_edit_buf) - 1) {
                ov->mgr_edit_buf[ov->mgr_edit_len++] = ch;
                ov->mgr_edit_buf[ov->mgr_edit_len] = '\0';
            }
        }
        return true;
    }

    switch (kc) {
    case SDLK_TAB:
        ov->mgr_focus = ov->mgr_focus == 0 ? 1 : 0;
        return true;
    case SDLK_UP:
        if (ov->mgr_focus == 0) {
            if (ov->mgr_tmpl_sel > 0) ov->mgr_tmpl_sel--;
        } else if (ov->mgr_entry_sel > 0) {
            ov->mgr_entry_sel--;
        }
        return true;
    case SDLK_DOWN:
        if (ov->mgr_focus == 0) {
            if (ov->mgr_tmpl_sel + 1 < ov->mgr_count) ov->mgr_tmpl_sel++;
        } else if (ov->mgr_entry_sel + 1 < mm->count) {
            ov->mgr_entry_sel++;
        }
        return true;
    case SDLK_RETURN:
    case SDLK_KP_ENTER: {
        if (ov->mgr_focus == 0) {
            if (ov->mgr_names && ov->mgr_tmpl_sel < ov->mgr_count) {
                const char *n = ov->mgr_names[ov->mgr_tmpl_sel];
                if (n && sc_mapping_manager_switch(mm, n)) {
                    char msg[128];
                    snprintf(msg, sizeof(msg), "Template: %s", n);
                    sc_overlay_manager_set_hint(ov, msg);
                    ov->mgr_entry_sel = 0;
                } else {
                    sc_overlay_manager_set_hint(ov, "Load failed");
                }
            }
            return true;
        }
        manager_begin_edit(im, 0);
        return true;
    }
    case SDLK_1: manager_begin_edit(im, 0); return true;
    case SDLK_2: manager_begin_edit(im, 1); return true;
    case SDLK_3: manager_begin_edit(im, 2); return true;
    case SDLK_4: manager_begin_edit(im, 3); return true;
    case SDLK_5: manager_begin_edit(im, 4); return true;
    case SDLK_6: manager_begin_edit(im, 5); return true;
    case SDLK_M:
        manager_toggle_mode(im);
        return true;
    case SDLK_D:
        manager_cycle_dep(im);
        return true;
    case SDLK_G:
        manager_cycle_flag_dep(im);
        return true;
    case SDLK_V:
        manager_create_motion(im);
        return true;
    case SDLK_H:
        manager_toggle_hold(im);
        return true;
    case SDLK_N:
        ov->mgr_capture_key = true;
        sc_overlay_manager_set_hint(ov, "Press the key to bind (Esc cancels)");
        return true;
    case SDLK_DELETE:
    case SDLK_X:
        manager_remove_selected(im);
        return true;
    case SDLK_T:
        manager_toggle_type(im);
        return true;
    case SDLK_P:
        ov->mgr_pick = 1;
        sc_overlay_manager_set_hint(ov, "Click a point on the video");
        return true;
    case SDLK_O:
        ov->mgr_pick = 2;
        sc_overlay_manager_set_hint(ov, "Click the slide end point");
        return true;
    case SDLK_E: {
        bool en = !mm->enabled;
        sc_mapping_manager_set_enabled(mm, en);
        sc_overlay_show_toggle(ov, en);
        sc_overlay_manager_set_hint(ov, en ? "Mapping enabled"
                                           : "Mapping disabled");
        return true;
    }
    case SDLK_S:
        if (sc_mapping_manager_save_active_force(mm)) {
            sc_overlay_manager_set_hint(ov, "Saved");
            sc_overlay_set_status(ov, "Template saved");
        } else {
            sc_overlay_manager_set_hint(ov, "Save failed");
        }
        return true;
    default:
        return true; // panel is modal: never forward keys while it is open
    }
}

static void
manager_handle_click(struct sc_input_manager *im, double win_x, double win_y) {
    struct sc_overlay *ov = ov_of(im);
    int win_w = 0, win_h = 0;
    SDL_GetWindowSize(im->screen->window, &win_w, &win_h);

    if (sc_overlay_manager_mouse(ov, (float) win_x, (float) win_y,
                                 win_w, win_h)) {
        return; // consumed by the panel
    }

    // Click on the video area: only used for coordinate picking
    if (ov->mgr_pick) {
        struct sc_point p = sc_screen_convert_window_to_frame_coords(
            im->screen, (float) win_x, (float) win_y);
        double nx = (double) p.x / im->screen->frame_size.width;
        double ny = (double) p.y / im->screen->frame_size.height;
        if (nx < 0) nx = 0;
        if (nx > 1) nx = 1;
        if (ny < 0) ny = 0;
        if (ny > 1) ny = 1;
        manager_pick_point(im, nx, ny);
    }
}


// ==================== 初始化 ====================

static bool
overlay_manager_open(struct sc_input_manager *im) {
    return ov_of(im)->mode == SC_OVERLAY_MANAGER;
}

// ==================== 内置功能标志（依赖源） ====================
//
// 每个内置功能只需要在这里注册一个具名布尔量，就能被模板的 "depends_on"
// 引用（"flag:<name>"）。后加的功能同样只需注册一个标志，无需再改动依赖
// 计算本身：解析器通过注册表解析名字，运行时通过同一个注册表求值。

static bool
cond_flag_mapping_enabled(void *ctx) {
    struct sc_input_manager *im = ctx;
    return mm_of(im)->enabled;
}

static bool
cond_flag_design_mode(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->design_mode;
}

static bool
cond_flag_manager_panel(void *ctx) {
    struct sc_input_manager *im = ctx;
    return ov_of(im)->mode == SC_OVERLAY_MANAGER;
}

static bool
cond_flag_switch_popup(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->switch_open;
}

// 视角模式：MOUSE_MOVE 条目为 hold:"always" 且虚拟手指当前已按下。
static bool
cond_flag_look_mode(void *ctx) {
    struct sc_input_manager *im = ctx;
    struct sc_mapping_entry *e = find_motion_entry(mm_of(im));
    if (!e || e->hold != SC_MOTION_HOLD_ALWAYS) {
        return false;
    }
    return im->motion.active;
}

// 鼠标位移映射正在驱动手指（视角模式或按住鼠标键拖动）。
static bool
cond_flag_motion_active(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->motion.active;
}

// 至少有一个滑动正在运行。
static bool
cond_flag_slide_active(void *ctx) {
    struct sc_input_manager *im = ctx;
    for (int i = 0; i < SC_MAX_SLIDES; i++) {
        if (im->slides[i].active) {
            return true;
        }
    }
    return false;
}

static bool
cond_flag_left_click_locked(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->left_click_locked;
}

static bool
cond_flag_mouse_any_down(void *ctx) {
    struct sc_input_manager *im = ctx;
    return motion_any_button_down(im);
}

static bool
cond_flag_device_connected(void *ctx) {
    struct sc_input_manager *im = ctx;
    return !im->disconnected;
}

static bool
cond_flag_device_paused(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->screen->paused;
}

static bool
cond_flag_camera(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->camera;
}

static bool
cond_flag_vfinger(void *ctx) {
    struct sc_input_manager *im = ctx;
    return im->vfinger_down;
}

// Register the built-in feature flags. Must run before the first template is
// loaded, so that "flag:<name>" references can be validated at load time.
static void
register_builtin_cond_flags(struct sc_input_manager *im) {
    sc_cond_flag_set_ctx(im);

    sc_cond_flag_register("mapping.enabled",
        "Mapping master switch is on", cond_flag_mapping_enabled);
    sc_cond_flag_register("mapping.design",
        "Design mode (F3) is active", cond_flag_design_mode);
    sc_cond_flag_register("mapping.panel",
        "Manager panel (F5) is open", cond_flag_manager_panel);
    sc_cond_flag_register("mapping.switch",
        "Template switch popup (F2) is open", cond_flag_switch_popup);

    sc_cond_flag_register("look_mode",
        "View mode: the latched mouse swipe is driving the finger",
        cond_flag_look_mode);
    sc_cond_flag_register("motion.active",
        "A mouse motion mapping is currently driving the finger",
        cond_flag_motion_active);
    sc_cond_flag_register("slide.active",
        "At least one hold-to-slide mapping is running",
        cond_flag_slide_active);

    sc_cond_flag_register("mouse.left_locked",
        "Left click lock is engaged", cond_flag_left_click_locked);
    sc_cond_flag_register("mouse.any_down",
        "Any mouse button is held down", cond_flag_mouse_any_down);

    sc_cond_flag_register("device.connected",
        "The device is connected", cond_flag_device_connected);
    sc_cond_flag_register("device.paused",
        "The stream is paused", cond_flag_device_paused);
    sc_cond_flag_register("camera",
        "Camera mirroring mode", cond_flag_camera);
    sc_cond_flag_register("vfinger",
        "The virtual finger (alt-drag) is down", cond_flag_vfinger);
}

void
sc_input_manager_init(struct sc_input_manager *im,
                      const struct sc_input_manager_params *params) {
    assert(!params->kp || params->kp->ops);
    assert(!params->mp || params->mp->ops);
    assert(!params->gp || params->gp->ops);

    im->controller = params->controller;
    im->fp = params->fp;
    im->screen = params->screen;
    im->kp = params->kp;
    im->mp = params->mp;
    im->gp = params->gp;
    im->camera = params->camera;

    im->mouse_bindings = params->mouse_bindings;
    im->legacy_paste = params->legacy_paste;
    im->clipboard_autosync = params->clipboard_autosync;

    im->sdl_shortcut_mods = sc_shortcut_mods_to_sdl(params->shortcut_mods);

    im->vfinger_down = false;
    im->vfinger_invert_x = false;
    im->vfinger_invert_y = false;

    im->mouse_buttons_state = 0;

    im->last_keycode = SDLK_UNKNOWN;
    im->last_mod = 0;
    im->key_repeat = 0;

    im->next_sequence = 1;

    im->disconnected = false;

    // custom mapping state
    memset(im->g_pressed, 0, sizeof(im->g_pressed));
    im->left_click_locked = false;
    im->left_click_locked_down = false;
    memset(im->map_mouse_down, 0, sizeof(im->map_mouse_down));
    memset(&im->motion, 0, sizeof(im->motion));
    im->design_mode = false;
    im->switch_open = false;

    sc_overlay_init(&im->screen->overlay);
    // The feature flags must exist before the first template is loaded: the
    // loader resolves "flag:<name>" references against the registry.
    register_builtin_cond_flags(im);
    sc_mapping_manager_init(&im->screen->mm);
    // The manager must be able to lift held fingers before it mutates entries.
    sc_mapping_manager_set_release_hook(&im->screen->mm, mapping_release_all, im);

    char status[160];
    snprintf(status, sizeof(status),
             "Template '%s': %d entries, %d rejected",
             im->screen->mm.active_name ? im->screen->mm.active_name : "-",
             im->screen->mm.count, im->screen->mm.last_load.fail);
    sc_overlay_set_status(&im->screen->overlay, status);
    for (int i = 0; i < im->screen->mm.last_load.nmsgs; i++) {
        LOGW("%s", im->screen->mm.last_load.msgs[i]);
    }
}

// ==================== SCRCPY 原有按键动作 ====================

static void
send_keycode(struct sc_input_manager *im, enum android_keycode keycode,
             enum sc_action action, const char *name) {
    assert(im->controller && im->kp && !im->camera);

    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_INJECT_KEYCODE;
    msg.inject_keycode.action = action == SC_ACTION_DOWN
                              ? AKEY_EVENT_ACTION_DOWN
                              : AKEY_EVENT_ACTION_UP;
    msg.inject_keycode.keycode = keycode;
    msg.inject_keycode.metastate = 0;
    msg.inject_keycode.repeat = 0;

    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'inject %s'", name);
    }
}

static inline void
action_home(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_HOME, action, "HOME");
}

static inline void
action_back(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_BACK, action, "BACK");
}

static inline void
action_app_switch(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_APP_SWITCH, action, "APP_SWITCH");
}

static inline void
action_power(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_POWER, action, "POWER");
}

static inline void
action_volume_up(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_VOLUME_UP, action, "VOLUME_UP");
}

static inline void
action_volume_down(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_VOLUME_DOWN, action, "VOLUME_DOWN");
}

static inline void
action_menu(struct sc_input_manager *im, enum sc_action action) {
    send_keycode(im, AKEYCODE_MENU, action, "MENU");
}

static void
press_back_or_turn_screen_on(struct sc_input_manager *im,
                             enum sc_action action) {
    assert(im->controller && im->kp && !im->camera);

    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_BACK_OR_SCREEN_ON;
    msg.back_or_screen_on.action = action == SC_ACTION_DOWN
                                 ? AKEY_EVENT_ACTION_DOWN
                                 : AKEY_EVENT_ACTION_UP;

    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'press back or turn screen on'");
    }
}

static void
expand_notification_panel(struct sc_input_manager *im) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_EXPAND_NOTIFICATION_PANEL;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'expand notification panel'");
    }
}

static void
expand_settings_panel(struct sc_input_manager *im) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_EXPAND_SETTINGS_PANEL;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'expand settings panel'");
    }
}

static void
collapse_panels(struct sc_input_manager *im) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_COLLAPSE_PANELS;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'collapse notification panel'");
    }
}

static bool
get_device_clipboard(struct sc_input_manager *im, enum sc_copy_key copy_key) {
    assert(im->controller && im->kp && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_GET_CLIPBOARD;
    msg.get_clipboard.copy_key = copy_key;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'get device clipboard'");
        return false;
    }
    return true;
}

static bool
set_device_clipboard(struct sc_input_manager *im, bool paste,
                     uint64_t sequence) {
    assert(im->controller && im->kp && !im->camera);

    char *text = SDL_GetClipboardText();
    if (!text) {
        LOGW("Could not get clipboard text: %s", SDL_GetError());
        return false;
    }

    char *text_dup = strdup(text);
    SDL_free(text);
    if (!text_dup) {
        LOGW("Could not strdup input text");
        return false;
    }

    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_SET_CLIPBOARD;
    msg.set_clipboard.sequence = sequence;
    msg.set_clipboard.text = text_dup;
    msg.set_clipboard.paste = paste;

    if (!sc_controller_push_msg(im->controller, &msg)) {
        free(text_dup);
        LOGW("Could not request 'set device clipboard'");
        return false;
    }
    return true;
}

static void
set_display_power(struct sc_input_manager *im, bool on) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_SET_DISPLAY_POWER;
    msg.set_display_power.on = on;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'set screen power mode'");
    }
}

static void
switch_fps_counter_state(struct sc_input_manager *im) {
    struct sc_fps_counter *fps_counter = &im->screen->fps_counter;
    if (sc_fps_counter_is_started(fps_counter)) {
        sc_fps_counter_stop(fps_counter);
    } else {
        sc_fps_counter_start(fps_counter);
    }
}

static void
clipboard_paste(struct sc_input_manager *im) {
    assert(im->controller && im->kp && !im->camera);

    char *text = SDL_GetClipboardText();
    if (!text) {
        LOGW("Could not get clipboard text: %s", SDL_GetError());
        return;
    }
    if (!*text) {
        SDL_free(text);
        return;
    }

    char *text_dup = strdup(text);
    SDL_free(text);
    if (!text_dup) {
        LOGW("Could not strdup input text");
        return;
    }

    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_INJECT_TEXT;
    msg.inject_text.text = text_dup;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        free(text_dup);
        LOGW("Could not request 'paste clipboard'");
    }
}

static void
rotate_device(struct sc_input_manager *im) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_ROTATE_DEVICE;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request device rotation");
    }
}

static void
open_hard_keyboard_settings(struct sc_input_manager *im) {
    assert(im->controller && !im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_OPEN_HARD_KEYBOARD_SETTINGS;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request opening hard keyboard settings");
    }
}

static void
reset_video(struct sc_input_manager *im) {
    assert(im->controller);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_RESET_VIDEO;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request reset video");
    }
}

static void
camera_set_torch(struct sc_input_manager *im, bool on) {
    assert(im->controller && im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_CAMERA_SET_TORCH;
    msg.camera_set_torch.on = on;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request setting camera torch");
    }
}

static void
camera_zoom_in(struct sc_input_manager *im) {
    assert(im->controller && im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_CAMERA_ZOOM_IN;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request camera zoom in");
    }
}

static void
camera_zoom_out(struct sc_input_manager *im) {
    assert(im->controller && im->camera);
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_CAMERA_ZOOM_OUT;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request camera zoom out");
    }
}

static void
apply_orientation_transform(struct sc_input_manager *im,
                            enum sc_orientation transform) {
    struct sc_screen *screen = im->screen;
    enum sc_orientation new_orientation =
        sc_orientation_apply(screen->orientation, transform);
    sc_screen_set_orientation(screen, new_orientation);
}

static void
sc_input_manager_process_text_input(struct sc_input_manager *im,
                                    const SDL_TextInputEvent *event) {
    if (im->camera || !im->kp || im->screen->paused || im->disconnected) {
        return;
    }
    if (!im->kp->ops->process_text) return;
    if (overlay_manager_open(im)) return; // panel is modal: no text forwarding

    uint16_t mod = sc_sdl_mod_normalize(SDL_GetModState());
    if (sc_shortcut_mods_is_shortcut_mod(im->sdl_shortcut_mods, mod)) return;

    struct sc_text_event evt = { .text = event->text };
    im->kp->ops->process_text(im->kp, &evt);
}

static bool
simulate_virtual_finger(struct sc_input_manager *im,
                        enum android_motionevent_action action,
                        struct sc_point point) {
    bool up = action == AMOTION_EVENT_ACTION_UP;
    struct sc_control_msg msg;
    msg.type = SC_CONTROL_MSG_TYPE_INJECT_TOUCH_EVENT;
    msg.inject_touch_event.action = action;
    msg.inject_touch_event.position.screen_size = im->screen->frame_size;
    msg.inject_touch_event.position.point = point;
    msg.inject_touch_event.pointer_id = SC_POINTER_ID_VIRTUAL_FINGER;
    msg.inject_touch_event.pressure = up ? 0.0f : 1.0f;
    msg.inject_touch_event.action_button = 0;
    msg.inject_touch_event.buttons = 0;
    if (!sc_controller_push_msg(im->controller, &msg)) {
        LOGW("Could not request 'inject virtual finger event'");
        return false;
    }
    return true;
}

static struct sc_point
inverse_point(struct sc_point point, struct sc_size size,
              bool invert_x, bool invert_y) {
    if (invert_x) point.x = size.width - point.x;
    if (invert_y) point.y = size.height - point.y;
    return point;
}

// ==================== 按键处理（含自定义映射拦截） ====================

static void
sc_input_manager_process_key(struct sc_input_manager *im,
                             const SDL_KeyboardEvent *event) {
    bool control = im->controller;
    bool paused = im->screen->paused;
    bool video = im->screen->video;
    bool disconnected = im->disconnected;

    SDL_Keycode sdl_keycode = event->key;
    uint16_t mod = sc_sdl_mod_normalize(event->mod);
    bool down = event->type == SDL_EVENT_KEY_DOWN;
    bool ctrl = mod & SDL_KMOD_CTRL;
    bool shift = mod & SDL_KMOD_SHIFT;
    bool repeat = event->repeat;

    struct sc_mapping_manager *mm = mm_of(im);
    struct sc_overlay *ov = ov_of(im);

    // ---- 管理面板（F5）打开时：键盘归面板独占 ----
    // F5 关闭；F3 关闭面板并切到设计模式（二者互斥）；其余按键交给面板，
    // 一律不转发到设备。
    if (overlay_manager_open(im)) {
        if (down && !repeat) {
            if (sdl_keycode == mm->sc_manager) {
                manager_close(im);
            } else if (sdl_keycode == mm->sc_design) {
                manager_close(im);
                toggle_design_mode(im);
            } else {
                manager_handle_key(im, sdl_keycode);
            }
        }
        return;
    }

    // ---- 全局快捷键（无论映射是否启用都响应） ----
    if (down && !repeat) {
        if (sdl_keycode == mm->sc_manager) {
            manager_open(im);
            return;
        }
        if (sdl_keycode == mm->sc_switch) {
            if (im->switch_open) close_template_switch(im);
            else open_template_switch(im);
            return;
        }
        // Esc closes the switch popup
        if (im->switch_open && sdl_keycode == SDLK_ESCAPE) {
            close_template_switch(im);
            return;
        }
        if (sdl_keycode == mm->sc_design) {
            toggle_design_mode(im);
            return;
        }
        if (sdl_keycode == mm->sc_toggle) {
            bool new_state = !mm->enabled;
            sc_mapping_manager_set_enabled(mm, new_state);
            sc_overlay_show_toggle(ov, new_state);
            return;
        }
    }

    // While the switch popup is open, suppress all other key input
    if (im->switch_open) {
        return;
    }

    // ---- 设计模式：按键绑定到待记录位置 ----
    if (im->design_mode && down && !repeat) {
        // Ignore modifier-only keys in design bind
        if (sdl_keycode != SDLK_LCTRL && sdl_keycode != SDLK_RCTRL &&
            sdl_keycode != SDLK_LSHIFT && sdl_keycode != SDLK_RSHIFT &&
            sdl_keycode != SDLK_LALT && sdl_keycode != SDLK_RALT &&
            sdl_keycode != SDLK_LGUI && sdl_keycode != SDLK_RGUI) {
            const char *name = sc_mapping_key_name(sdl_keycode);
            if (sc_mapping_manager_design_bind(mm, name)) {
                char buf[128];
                snprintf(buf, sizeof(buf), "Bound %s", name);
                sc_overlay_set_status(ov, buf);
            } else if (!sc_mapping_manager_design_has_point(mm)) {
                sc_overlay_set_status(ov,
                    "Click a position first, then press a key");
            }
            return;
        }
    }

    // ---- 自定义映射拦截（仅当启用且非设计模式） ----
    if (mm->enabled && !im->design_mode && control && !paused
            && !disconnected && !im->camera) {
        // 左 Alt 切换左键锁定
        if (sdl_keycode == SDLK_LALT && down && !repeat && !ctrl && !shift) {
            im->left_click_locked = !im->left_click_locked;
            im->left_click_locked_down = false;
            LOGI("Left click lock: %s", im->left_click_locked ? "ON" : "OFF");
            return;
        }

        bool is_mapping_key =
            sc_mapping_manager_find_single(mm, sdl_keycode) != NULL;
        bool is_combo_key = sc_mapping_manager_key_in_combo(mm, sdl_keycode);
        // A dependency key may not be mapped at all, but its state must still
        // be tracked, otherwise the dependency could never change.
        bool is_dep_key =
            sc_mapping_manager_key_is_dependency(mm, sdl_keycode);

        if (is_mapping_key || is_combo_key || is_dep_key) {
            if (down && repeat) return;  // 忽略键盘自动重复

            im->g_pressed[sdl_keycode & 0xFF] = down;

            update_combos(im);

            struct sc_mapping_entry *m =
                sc_mapping_manager_find_single(mm, sdl_keycode);
            if (m && !m->is_mouse) {
                // 如果该键被已激活的 combo 覆盖，跳过单键逻辑
                bool covered = false;
                for (int i = 0; i < SC_MAPPING_MAX_ENTRIES; ++i) {
                    struct sc_mapping_entry *c = &mm->entries[i];
                    if (!c->key_name || !c->active) continue;
                    for (int j = 0; j < c->nkeys; ++j) {
                        if (c->keys[j] == sdl_keycode) { covered = true; break; }
                    }
                    if (covered) break;
                }
                if (covered) {
                    if (!down && (m->active || m->down)) {
                        entry_deactivate(im, m);
                    }
                } else if (m->mode == SC_MAPPING_MODE_TOGGLE) {
                    // Toggle flips on the press edge only; the release edge
                    // must not touch the injected state.
                    if (down) {
                        if (m->active) {
                            entry_deactivate(im, m);
                        } else {
                            entry_activate(im, m);
                        }
                    }
                } else if (down) {
                    entry_activate(im, m);
                } else {
                    entry_deactivate(im, m);
                }
            }

            // Any key state change may satisfy or break a dependency.
            evaluate_dependencies(im);

            // Dependency-only keys keep their normal forwarding.
            if (is_mapping_key || is_combo_key) return;
        }
    }

    // ---- 以下为 SCRCPY 原有逻辑 ----

    uint16_t mods = im->sdl_shortcut_mods;
    bool is_shortcut = sc_shortcut_mods_is_shortcut_mod(mods, mod)
                    || sc_shortcut_mods_is_shortcut_key(mods, sdl_keycode);

    if (down && !repeat && !disconnected) {
        if (sdl_keycode == im->last_keycode && mod == im->last_mod) {
            ++im->key_repeat;
        } else {
            im->key_repeat = 0;
            im->last_keycode = sdl_keycode;
            im->last_mod = mod;
        }
    }

    switch (sdl_keycode) {
        case SDLK_F11:
            if (video && !repeat && down) {
                bool alt = mod & SDL_KMOD_ALT;
                bool super = mod & SDL_KMOD_GUI;
                if (!ctrl && !shift && !alt && !super) {
                    sc_screen_toggle_fullscreen(im->screen);
                }
            }
            return;
    }

    if (is_shortcut) {
        enum sc_action action = down ? SC_ACTION_DOWN : SC_ACTION_UP;
        switch (sdl_keycode) {
            case SDLK_Z:
                if (video && down && !repeat) sc_screen_set_paused(im->screen, !shift);
                return;
            case SDLK_DOWN:
                if (shift) {
                    if (video && !repeat && down) apply_orientation_transform(im, SC_ORIENTATION_FLIP_180);
                    return;
                }
                break;
            case SDLK_UP:
                if (shift) {
                    if (video && !repeat && down) apply_orientation_transform(im, SC_ORIENTATION_FLIP_180);
                    return;
                }
                break;
            case SDLK_LEFT:
                if (video && !repeat && down) {
                    if (shift) apply_orientation_transform(im, SC_ORIENTATION_FLIP_0);
                    else apply_orientation_transform(im, SC_ORIENTATION_270);
                }
                return;
            case SDLK_RIGHT:
                if (video && !repeat && down) {
                    if (shift) apply_orientation_transform(im, SC_ORIENTATION_FLIP_0);
                    else apply_orientation_transform(im, SC_ORIENTATION_90);
                }
                return;
            case SDLK_F:
                if (video && !shift && !repeat && down) sc_screen_toggle_fullscreen(im->screen);
                return;
            case SDLK_W:
                if (video && !shift && !repeat && down) sc_screen_resize_to_fit(im->screen);
                return;
            case SDLK_G:
                if (video && !shift && !repeat && down) sc_screen_resize_to_pixel_perfect(im->screen);
                return;
            case SDLK_I:
                if (video && !shift && !repeat && down) switch_fps_counter_state(im);
                return;
            case SDLK_Q:
                sc_push_event(SDL_EVENT_QUIT);
                return;
        }

        if (disconnected) return;

        if (control) {
            switch (sdl_keycode) {
                case SDLK_R:
                    if (shift) {
                        if (!repeat && down && !paused) reset_video(im);
                        return;
                    }
                    break;
            }
        }

        if (control && !im->camera) {
            switch (sdl_keycode) {
                case SDLK_H:
                    if (im->kp && !shift && !repeat && !paused) action_home(im, action);
                    return;
                case SDLK_B:
                case SDLK_BACKSPACE:
                    if (im->kp && !shift && !repeat && !paused) action_back(im, action);
                    return;
                case SDLK_S:
                    if (im->kp && !shift && !repeat && !paused) action_app_switch(im, action);
                    return;
                case SDLK_M:
                    if (im->kp && !shift && !repeat && !paused) action_menu(im, action);
                    return;
                case SDLK_P:
                    if (im->kp && !shift && !repeat && !paused) action_power(im, action);
                    return;
                case SDLK_O:
                    if (control && !repeat && down && !paused) {
                        bool on = shift;
                        set_display_power(im, on);
                    }
                    return;
                case SDLK_DOWN:
                    if (im->kp && !shift && !paused) action_volume_down(im, action);
                    return;
                case SDLK_UP:
                    if (im->kp && !shift && !paused) action_volume_up(im, action);
                    return;
                case SDLK_C:
                    if (im->kp && !shift && !repeat && down && !paused) get_device_clipboard(im, SC_COPY_KEY_COPY);
                    return;
                case SDLK_X:
                    if (im->kp && !shift && !repeat && down && !paused) get_device_clipboard(im, SC_COPY_KEY_CUT);
                    return;
                case SDLK_V:
                    if (im->kp && !repeat && down && !paused) {
                        if (shift || im->legacy_paste) clipboard_paste(im);
                        else set_device_clipboard(im, true, SC_SEQUENCE_INVALID);
                    }
                    return;
                case SDLK_N:
                    if (!repeat && down && !paused) {
                        if (shift) collapse_panels(im);
                        else if (im->key_repeat == 0) expand_notification_panel(im);
                        else expand_settings_panel(im);
                    }
                    return;
                case SDLK_R:
                    if (!repeat && !shift && down && !paused) rotate_device(im);
                    return;
                case SDLK_K:
                    if (!shift && !repeat && down && !paused && im->kp && im->kp->hid)
                        open_hard_keyboard_settings(im);
                    return;
            }
        }

        if (control && im->camera) {
            switch (sdl_keycode) {
                case SDLK_T:
                    if (!repeat && down) camera_set_torch(im, !shift);
                    return;
                case SDLK_DOWN:
                    if (!shift && down && !paused) camera_zoom_out(im);
                    return;
                case SDLK_UP:
                    if (!shift && down && !paused) camera_zoom_in(im);
                    return;
            }
        }
        return;
    }

    if (!im->kp || paused) return;
    assert(!im->camera);

    uint64_t ack_to_wait = SC_SEQUENCE_INVALID;
    bool is_ctrl_v = ctrl && !shift && sdl_keycode == SDLK_V && down && !repeat;
    if (im->clipboard_autosync && is_ctrl_v) {
        if (im->legacy_paste) {
            clipboard_paste(im);
            return;
        }
        uint64_t sequence = im->kp->async_paste ? im->next_sequence : SC_SEQUENCE_INVALID;
        bool ok = set_device_clipboard(im, false, sequence);
        if (!ok) {
            LOGW("Clipboard could not be synchronized, Ctrl+v not injected");
            return;
        }
        if (im->kp->async_paste) {
            ack_to_wait = sequence;
            ++im->next_sequence;
        }
    }

    enum sc_keycode keycode = sc_keycode_from_sdl(sdl_keycode);
    enum sc_scancode scancode = sc_scancode_from_sdl(event->scancode);
    if (scancode == SC_SCANCODE_UNKNOWN) return;

    struct sc_key_event evt = {
        .action = sc_action_from_sdl_keyboard_type(event->type),
        .keycode = keycode,
        .scancode = scancode,
        .repeat = event->repeat,
        .mods_state = sc_mods_state_from_sdl(mod),
    };
    assert(im->kp->ops->process_key);
    im->kp->ops->process_key(im->kp, &evt, ack_to_wait);
}

static struct sc_position
sc_input_manager_get_position(struct sc_input_manager *im, int32_t x, int32_t y) {
    if (im->mp->relative_mode) {
        return (struct sc_position) { .screen_size = {0, 0}, .point = {0, 0} };
    }
    return (struct sc_position) {
        .screen_size = im->screen->frame_size,
        .point = sc_screen_convert_window_to_frame_coords(im->screen, x, y),
    };
}

static void
sc_input_manager_process_mouse_motion(struct sc_input_manager *im,
                                      const SDL_MouseMotionEvent *event) {
    if (im->camera || !im->mp || im->screen->paused || im->disconnected) return;
    if (event->which == SDL_TOUCH_MOUSEID) return;

    // 管理面板打开时鼠标移动不转发到设备（面板本身由键盘驱动）；面板关闭后
    // 转发行为与打开前完全一致。
    if (overlay_manager_open(im)) {
        motion_stop(im); // never leave a synthetic swipe held under the panel
        return;
    }

    // If switch popup is open, update hover (and request a debounced switch)
    if (im->switch_open) {
        motion_stop(im);
        int hovered = sc_overlay_update_switch_mouse(ov_of(im),
                                                     (float)event->x,
                                                     (float)event->y);
        if (hovered >= 0) {
            char **names = ov_of(im)->names;
            if (names && names[hovered]) {
                // No file I/O here: the switch is applied later by the tick,
                // after the hover has been stable for a short delay.
                sc_mapping_manager_request_switch(mm_of(im), names[hovered]);
            }
        }
        return;
    }

    // Mouse-motion mapping: while any mouse button is held, the delta drives a
    // synthetic swipe. Consumed in that case so the physical pointer (and the
    // virtual finger) does not fight the injected one for the same device.
    if (motion_feed(im, event->xrel, event->yrel)) {
        return;
    }

    struct sc_mouse_motion_event evt = {
        .position = sc_input_manager_get_position(im, event->x, event->y),
        .pointer_id = im->vfinger_down ? SC_POINTER_ID_GENERIC_FINGER : SC_POINTER_ID_MOUSE,
        .xrel = event->xrel,
        .yrel = event->yrel,
        .buttons_state = im->mouse_buttons_state,
    };
    assert(im->mp->ops->process_mouse_motion);
    im->mp->ops->process_mouse_motion(im->mp, &evt);

    if (im->vfinger_down) {
        struct sc_point mouse = sc_screen_convert_window_to_frame_coords(im->screen, event->x, event->y);
        struct sc_point vfinger = inverse_point(mouse, im->screen->frame_size, im->vfinger_invert_x, im->vfinger_invert_y);
        simulate_virtual_finger(im, AMOTION_EVENT_ACTION_MOVE, vfinger);
    }
}

static void
sc_input_manager_process_touch(struct sc_input_manager *im,
                               const SDL_TouchFingerEvent *event) {
    if (im->camera || !im->mp || im->screen->paused || im->disconnected) return;
    if (!im->mp->ops->process_touch) return;
    if (overlay_manager_open(im)) return; // panel is modal: no touch forwarding

    struct sc_size window_size = sc_sdl_get_window_size(im->screen->window);
    int32_t x = event->x * (int32_t)window_size.width;
    int32_t y = event->y * (int32_t)window_size.height;

    struct sc_touch_event evt = {
        .position = {
            .screen_size = im->screen->frame_size,
            .point = sc_screen_convert_window_to_frame_coords(im->screen, x, y),
        },
        .action = sc_touch_action_from_sdl(event->type),
        .pointer_id = event->fingerID,
        .pressure = event->pressure,
    };
    im->mp->ops->process_touch(im->mp, &evt);
}

static enum sc_mouse_binding
sc_input_manager_get_binding(const struct sc_mouse_binding_set *bindings,
                             uint8_t sdl_button) {
    switch (sdl_button) {
        case SDL_BUTTON_LEFT: return SC_MOUSE_BINDING_CLICK;
        case SDL_BUTTON_RIGHT: return bindings->right_click;
        case SDL_BUTTON_MIDDLE: return bindings->middle_click;
        case SDL_BUTTON_X1: return bindings->click4;
        case SDL_BUTTON_X2: return bindings->click5;
        default: return SC_MOUSE_BINDING_DISABLED;
    }
}

static void
sc_input_manager_process_mouse_button(struct sc_input_manager *im,
                                      const SDL_MouseButtonEvent *event) {
    if (im->camera || im->disconnected) return;
    if (event->which == SDL_TOUCH_MOUSEID) return;

    bool control = im->controller;
    bool paused = im->screen->paused;
    bool down = event->type == SDL_EVENT_MOUSE_BUTTON_DOWN;

    // Track the physical button state first, before any early return (design
    // mode, switch popup, manager panel): a button pressed before entering an
    // overlay must not stay "held" for the motion mapping after leaving it.
    if (event->button >= 1 && event->button <= 5) {
        im->map_mouse_down[event->button] = down;
    }

    // Button-gated motion (hold != always) must stop as soon as no mouse
    // button is held, even if no further motion event arrives. Stopping here
    // releases the relative-mouse capture immediately, so the cursor does not
    // stay hidden until the next mouse wiggle. Latched (look) mode is untouched.
    if (im->motion.active) {
        struct sc_mapping_entry *e = find_motion_entry(mm_of(im));
        bool latched = e && e->hold == SC_MOTION_HOLD_ALWAYS;
        if (!latched && !motion_any_button_down(im)) {
            motion_stop(im);
        }
    }

    // 管理面板打开时鼠标归面板所有：左键用于列表选择 / 取点，其它键吞掉，
    // 全部不转发到设备。关闭面板时 manager_close() 会复位按键与锁定状态。
    if (overlay_manager_open(im)) {
        if (down && event->button == SDL_BUTTON_LEFT) {
            manager_handle_click(im, event->x, event->y);
        }
        return;
    }

    struct sc_mapping_manager *mm = mm_of(im);

    // 设计模式：右键切换记录类型（单点 / 滑动两点）
    if (im->design_mode && event->button == SDL_BUTTON_RIGHT && down) {
        mm->design_is_slide = !mm->design_is_slide;
        sc_mapping_manager_design_reset(mm);
        const char *hint = mm->design_is_slide
            ? "Design SLIDE: click twice (start / end), then a key. "
              "Right click = touch mode. F3 = exit."
            : "Design TOUCH: click a position, then a key. "
              "Right click = slide mode. F3 = exit.";
        sc_overlay_set_design(ov_of(im), true, hint);
        sc_overlay_set_status(ov_of(im), hint);
        return;
    }

    // 设计模式：左键点击记录位置
    if (im->design_mode && event->button == SDL_BUTTON_LEFT && down) {
        struct sc_point p = sc_screen_convert_window_to_frame_coords(
            im->screen, event->x, event->y);
        double nx = (double)p.x / im->screen->frame_size.width;
        double ny = (double)p.y / im->screen->frame_size.height;
        if (nx < 0) nx = 0;
        if (nx > 1) nx = 1;
        if (ny < 0) ny = 0;
        if (ny > 1) ny = 1;
        sc_mapping_manager_design_click(mm, nx, ny);
        char buf[160];
        if (mm->design_is_slide && mm->design_stage == 1) {
            snprintf(buf, sizeof(buf),
                     "Slide start (%.3f, %.3f). Click the end point.",
                     nx, ny);
        } else if (mm->design_is_slide && mm->design_stage == 2) {
            snprintf(buf, sizeof(buf),
                     "Slide recorded (d=%.3f, %.3f, %dms). Press a key.",
                     mm->design_dx, mm->design_dy, mm->design_duration_ms);
        } else {
            snprintf(buf, sizeof(buf),
                     "Position recorded (%.3f, %.3f). Press a key to bind.",
                     nx, ny);
        }
        sc_overlay_set_status(ov_of(im), buf);
        sc_overlay_set_design(ov_of(im), true, buf);
        return;
    }

    // 切换弹窗打开时，点击关闭
    if (im->switch_open) {
        close_template_switch(im);
        return;
    }

    // ==================== 自定义鼠标拦截 ====================
    if (mm->enabled && !im->design_mode && control && !paused) {
        // 左键锁定（保留原有语义，优先于普通 MOUSE_LEFT 绑定）
        if (event->button == SDL_BUTTON_LEFT && im->left_click_locked) {
            if (down == im->left_click_locked_down) return;
            im->left_click_locked_down = down;
            enum android_motionevent_action action = down
                ? AMOTION_EVENT_ACTION_DOWN : AMOTION_EVENT_ACTION_UP;
            // Index lookup, never a stored pointer (entries are a fixed table
            // and are replaced on reload)
            int idx = mm->mouse_left_locked_idx;
            if (idx >= 0 && mm->entries[idx].key_name) {
                inject_entry(im, &mm->entries[idx], action);
            }
            return;
        }

        // Any button bound in the template (MOUSE_LEFT / MOUSE_MIDDLE /
        // MOUSE_RIGHT / MOUSE_X1 / MOUSE_X2) is consumed and injected instead
        // of being forwarded to the device.
        SDL_Keycode mkc = SC_MAPPING_MOUSE_KEY(event->button);
        struct sc_mapping_entry *m = sc_mapping_manager_find_single(mm, mkc);
        if (m) {
            if (m->mode == SC_MAPPING_MODE_TOGGLE) {
                if (down) {
                    if (m->active) {
                        entry_deactivate(im, m);
                    } else {
                        entry_activate(im, m);
                    }
                }
            } else if (down) {
                entry_activate(im, m);
            } else {
                entry_deactivate(im, m);
            }
        }

        // A mouse button may also be a dependency source (for single entries
        // and for combos: update_combos() re-checks dep_ok()).
        update_combos(im);
        evaluate_dependencies(im);

        if (m) return;
    }

    enum sc_mouse_button button = sc_mouse_button_from_sdl(event->button);
    if (button == SC_MOUSE_BUTTON_UNKNOWN) return;

    if (!down) im->mouse_buttons_state &= ~button;

    SDL_Keymod keymod = SDL_GetModState();
    bool ctrl_pressed = keymod & SDL_KMOD_CTRL;
    bool shift_pressed = keymod & SDL_KMOD_SHIFT;

    if (control && !paused) {
        enum sc_action action = down ? SC_ACTION_DOWN : SC_ACTION_UP;
        struct sc_mouse_binding_set *bindings = !shift_pressed
                                              ? &im->mouse_bindings.pri
                                              : &im->mouse_bindings.sec;
        enum sc_mouse_binding binding = sc_input_manager_get_binding(bindings, event->button);
        assert(binding != SC_MOUSE_BINDING_AUTO);
        switch (binding) {
            case SC_MOUSE_BINDING_DISABLED: return;
            case SC_MOUSE_BINDING_BACK:
                if (im->kp) press_back_or_turn_screen_on(im, action);
                return;
            case SC_MOUSE_BINDING_HOME:
                if (im->kp) action_home(im, action);
                return;
            case SC_MOUSE_BINDING_APP_SWITCH:
                if (im->kp) action_app_switch(im, action);
                return;
            case SC_MOUSE_BINDING_EXPAND_NOTIFICATION_PANEL:
                if (down) {
                    if (event->clicks < 2) expand_notification_panel(im);
                    else expand_settings_panel(im);
                }
                return;
            default: assert(binding == SC_MOUSE_BINDING_CLICK); break;
        }
    }

    bool video = im->screen->video;
    bool mouse_relative_mode = im->mp && im->mp->relative_mode;
    if (video && !mouse_relative_mode && event->button == SDL_BUTTON_LEFT && event->clicks == 2) {
        int32_t x = event->x;
        int32_t y = event->y;
        SDL_FRect *r = &im->screen->rect;
        bool outside = x < r->x || x >= r->x + r->w || y < r->y || y >= r->y + r->h;
        if (outside) {
            if (down) sc_screen_resize_to_fit(im->screen);
            return;
        }
    }

    if (!im->mp || paused) return;

    if (down) im->mouse_buttons_state |= button;

    bool change_vfinger = event->button == SDL_BUTTON_LEFT &&
            ((down && !im->vfinger_down && (ctrl_pressed || shift_pressed)) ||
             (!down && im->vfinger_down));
    bool use_finger = im->vfinger_down || change_vfinger;

    struct sc_mouse_click_event evt = {
        .position = sc_input_manager_get_position(im, event->x, event->y),
        .action = sc_action_from_sdl_mousebutton_type(event->type),
        .button = button,
        .pointer_id = use_finger ? SC_POINTER_ID_GENERIC_FINGER : SC_POINTER_ID_MOUSE,
        .buttons_state = im->mouse_buttons_state,
    };
    assert(im->mp->ops->process_mouse_click);
    im->mp->ops->process_mouse_click(im->mp, &evt);

    if (im->mp->relative_mode) return;

    if (change_vfinger) {
        struct sc_point mouse = sc_screen_convert_window_to_frame_coords(im->screen, event->x, event->y);
        if (down) {
            im->vfinger_invert_x = ctrl_pressed ^ shift_pressed;
            im->vfinger_invert_y = ctrl_pressed;
        }
        struct sc_point vfinger = inverse_point(mouse, im->screen->frame_size, im->vfinger_invert_x, im->vfinger_invert_y);
        enum android_motionevent_action action = down ? AMOTION_EVENT_ACTION_DOWN : AMOTION_EVENT_ACTION_UP;
        if (!simulate_virtual_finger(im, action, vfinger)) return;
        im->vfinger_down = down;
    }
}

static void
sc_input_manager_process_mouse_wheel(struct sc_input_manager *im,
                                     const SDL_MouseWheelEvent *event) {
    if (im->camera || !im->kp || im->screen->paused || im->disconnected) return;
    if (!im->mp->ops->process_mouse_scroll) return;
    if (overlay_manager_open(im)) return; // panel is modal: no scrolling

    float mouse_x, mouse_y;
    uint32_t buttons = SDL_GetMouseState(&mouse_x, &mouse_y);
    (void)buttons;

    struct sc_mouse_scroll_event evt = {
        .position = sc_input_manager_get_position(im, (int32_t)mouse_x, (int32_t)mouse_y),
        .hscroll = event->x,
        .vscroll = event->y,
        .buttons_state = im->mouse_buttons_state,
    };
    im->mp->ops->process_mouse_scroll(im->mp, &evt);
}

static void
sc_input_manager_process_gamepad_device(struct sc_input_manager *im,
                                       const SDL_GamepadDeviceEvent *event) {
    if (im->camera || !im->gp || im->disconnected) return;

    if (event->type == SDL_EVENT_GAMEPAD_ADDED) {
        SDL_Gamepad *sdl_gamepad = SDL_OpenGamepad(event->which);
        if (!sdl_gamepad) {
            LOGW("Could not open gamepad: %s", SDL_GetError());
            return;
        }
        SDL_Joystick *joystick = SDL_GetGamepadJoystick(sdl_gamepad);
        if (!joystick) {
            LOGW("Could not get gamepad joystick: %s", SDL_GetError());
            SDL_CloseGamepad(sdl_gamepad);
            return;
        }
        struct sc_gamepad_device_event evt = { .gamepad_id = SDL_GetJoystickID(joystick) };
        im->gp->ops->process_gamepad_added(im->gp, &evt);
    } else if (event->type == SDL_EVENT_GAMEPAD_REMOVED) {
        SDL_JoystickID id = event->which;
        SDL_Gamepad *sdl_gamepad = SDL_GetGamepadFromID(id);
        if (sdl_gamepad) SDL_CloseGamepad(sdl_gamepad);
        else LOGW("Unknown gamepad device removed");
        struct sc_gamepad_device_event evt = { .gamepad_id = id };
        im->gp->ops->process_gamepad_removed(im->gp, &evt);
    }
}

static void
sc_input_manager_process_gamepad_axis(struct sc_input_manager *im,
                                      const SDL_GamepadAxisEvent *event) {
    if (im->camera || !im->gp || im->screen->paused || im->disconnected) return;
    enum sc_gamepad_axis axis = sc_gamepad_axis_from_sdl(event->axis);
    if (axis == SC_GAMEPAD_AXIS_UNKNOWN) return;
    struct sc_gamepad_axis_event evt = {
        .gamepad_id = event->which,
        .axis = axis,
        .value = event->value,
    };
    im->gp->ops->process_gamepad_axis(im->gp, &evt);
}

static void
sc_input_manager_process_gamepad_button(struct sc_input_manager *im,
                                       const SDL_GamepadButtonEvent *event) {
    if (im->camera || !im->gp || im->screen->paused || im->disconnected) return;
    enum sc_gamepad_button button = sc_gamepad_button_from_sdl(event->button);
    if (button == SC_GAMEPAD_BUTTON_UNKNOWN) return;
    struct sc_gamepad_button_event evt = {
        .gamepad_id = event->which,
        .action = sc_action_from_sdl_gamepad_button_type(event->type),
        .button = button,
    };
    im->gp->ops->process_gamepad_button(im->gp, &evt);
}

static bool
is_apk(const char *file) {
    const char *ext = strrchr(file, '.');
    return ext && !strcmp(ext, ".apk");
}

static void
sc_input_manager_process_file(struct sc_input_manager *im,
                              const SDL_DropEvent *event) {
    if (im->camera || !im->controller || im->disconnected) return;
    assert(event->type == SDL_EVENT_DROP_FILE);
    char *file = strdup(event->data);
    if (!file) {
        LOG_OOM();
        return;
    }
    enum sc_file_pusher_action action;
    if (is_apk(file)) action = SC_FILE_PUSHER_ACTION_INSTALL_APK;
    else action = SC_FILE_PUSHER_ACTION_PUSH_FILE;
    bool ok = sc_file_pusher_request(im->fp, action, file);
    if (!ok) free(file);
}

static void
sc_input_manager_on_device_disconnected(struct sc_input_manager *im) {
    im->disconnected = true;
    struct sc_fps_counter *fps_counter = &im->screen->fps_counter;
    if (sc_fps_counter_is_started(fps_counter)) sc_fps_counter_stop(fps_counter);
}

void
sc_input_manager_handle_event(struct sc_input_manager *im,
                              const SDL_Event *event) {
    switch (event->type) {
        case SDL_EVENT_TEXT_INPUT:
            sc_input_manager_process_text_input(im, &event->text);
            break;
        case SDL_EVENT_KEY_DOWN:
        case SDL_EVENT_KEY_UP:
            sc_input_manager_process_key(im, &event->key);
            break;
        case SDL_EVENT_MOUSE_MOTION:
            sc_input_manager_process_mouse_motion(im, &event->motion);
            break;
        case SDL_EVENT_MOUSE_WHEEL:
            sc_input_manager_process_mouse_wheel(im, &event->wheel);
            break;
        case SDL_EVENT_MOUSE_BUTTON_DOWN:
        case SDL_EVENT_MOUSE_BUTTON_UP:
            sc_input_manager_process_mouse_button(im, &event->button);
            break;
        case SDL_EVENT_FINGER_MOTION:
        case SDL_EVENT_FINGER_DOWN:
        case SDL_EVENT_FINGER_UP:
            sc_input_manager_process_touch(im, &event->tfinger);
            break;
        case SDL_EVENT_GAMEPAD_ADDED:
        case SDL_EVENT_GAMEPAD_REMOVED:
            sc_input_manager_process_gamepad_device(im, &event->gdevice);
            break;
        case SDL_EVENT_GAMEPAD_AXIS_MOTION:
            sc_input_manager_process_gamepad_axis(im, &event->gaxis);
            break;
        case SDL_EVENT_GAMEPAD_BUTTON_DOWN:
        case SDL_EVENT_GAMEPAD_BUTTON_UP:
            sc_input_manager_process_gamepad_button(im, &event->gbutton);
            break;
        case SDL_EVENT_DROP_FILE:
            sc_input_manager_process_file(im, &event->drop);
            break;
        case SC_EVENT_DEVICE_DISCONNECTED:
            sc_input_manager_on_device_disconnected(im);
            break;
        case SDL_EVENT_WINDOW_FOCUS_LOST:
            // Losing focus must stop every slide and the motion swipe (the key
            // up / button release will never arrive)
            slide_stop_all(im);
            motion_stop(im);
            break;
    }
}
