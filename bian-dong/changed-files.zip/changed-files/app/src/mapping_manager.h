#ifndef SC_MAPPING_MANAGER_H
#define SC_MAPPING_MANAGER_H

#include "common.h"

#include <stdbool.h>
#include <stdint.h>
#include <SDL3/SDL_keycode.h>

#include "mapping_cond.h"
#include "util/tick.h"

// Maximum number of members of a key combo (entry trigger or dependency).
#define SC_MAPPING_MAX_KEYS SC_COND_MAX_KEYS
// A single key may map to several screen positions (simultaneous multi-touch).
// The server supports MAX_POINTERS = 10; we cap well below that.
#define SC_MAPPING_MAX_POSITIONS 5
// Fixed-capacity entry table: realloc is forbidden, because other modules keep
// indices (and index-based lookups) into this array across calls.
#define SC_MAPPING_MAX_ENTRIES 256
// Reserved pointer ids used by scrcpy for the physical mouse / virtual finger.
#define SC_MAPPING_PID_MIN 4  // first free id is -(4)
#define SC_MAPPING_PID_MAX (SC_MAPPING_MAX_ENTRIES + 3)

#define SC_MAPPING_MAX_FAILS 16

enum sc_mapping_entry_type {
    SC_MAPPING_TYPE_TOUCH = 0,   // tap: press at (nx, ny)
    SC_MAPPING_TYPE_SLIDE = 1,   // hold-to-slide: from (nx, ny) by (ndx, ndy)
    SC_MAPPING_TYPE_MOTION = 2,  // mouse motion -> continuous swipe (MOUSE_MOVE)
};

// How a mapping reacts to its trigger key/button.
enum sc_mapping_mode {
    SC_MAPPING_MODE_MOMENTARY = 0, // press = down, release = up (default)
    SC_MAPPING_MODE_TOGGLE = 1,    // each press flips the injected state
};

// Lifetime of the synthetic finger created by a motion ("MOUSE_MOVE") entry.
enum sc_motion_hold {
    SC_MOTION_HOLD_BUTTON = 0, // only while a mouse button is held (default)
    SC_MOTION_HOLD_ALWAYS = 1, // look mode: finger stays down until mapping off
};

// Mouse buttons are expressed as synthetic keycodes: real SDL keycodes are
// never negative, so these can neither collide with nor be produced by a
// keyboard event. Button numbers follow SDL (1 = left ... 5 = X2).
// SDL_Keycode is unsigned, so the range test is done on the signed value.
#define SC_MAPPING_MOUSE_KEY_BASE (-1000)
#define SC_MAPPING_MOUSE_KEY(button) (SC_MAPPING_MOUSE_KEY_BASE - (button))
#define SC_MAPPING_KEYCODE_IS_MOUSE(kc) \
    ((int) (kc) <= SC_MAPPING_MOUSE_KEY(1) \
     && (int) (kc) >= SC_MAPPING_MOUSE_KEY(5))
#define SC_MAPPING_KEYCODE_MOUSE_BUTTON(kc) \
    (SC_MAPPING_MOUSE_KEY_BASE - (int) (kc))

// Mouse-motion sensitivity defaults / accepted range (also documented).
#define SC_MAPPING_SENSITIVITY_DEFAULT 1.0
#define SC_MAPPING_SENSITIVITY_MIN 0.05
#define SC_MAPPING_SENSITIVITY_MAX 20.0

// Result of the latest template load, exposed for logging and for the overlay.
struct sc_mapping_load_stats {
    int ok;
    int fail;
    int nmsgs;
    char msgs[SC_MAPPING_MAX_FAILS][192];
};

// A single mapping entry: one key (or a key combo) mapped to a normalized
// position (nx, ny in [0.0, 1.0]), optionally a continuous slide.
struct sc_mapping_entry {
    char *key_name;                        // NULL means the slot is free
    SDL_Keycode keys[SC_MAPPING_MAX_KEYS]; // parsed keycodes (empty for mouse)
    int nkeys;                             // 0 = special mouse entry
    enum sc_mapping_entry_type type;
    enum sc_mapping_mode mode;             // momentary (default) or toggle
    double nx;                             // primary position (index 0)
    double ny;
    // Multi-touch: additional positions (indices 1 .. npositions-1). When
    // npositions > 1 the key presses every position at once (separate
    // pointer ids). Slide and motion always use the primary position only.
    int npositions;                        // 1 = single (default)
    double extra_nx[SC_MAPPING_MAX_POSITIONS - 1];
    double extra_ny[SC_MAPPING_MAX_POSITIONS - 1];
    int32_t extra_pid[SC_MAPPING_MAX_POSITIONS - 1];
    // Virtual key: never injects a touch, only tracks logical state so other
    // entries can depend on it or include it in a combo. Has no position and
    // no pointer id.
    bool is_virtual;
    double ndx;        // slide only
    double ndy;        // slide only
    int duration_ms;   // slide only
    double sensitivity; // motion only
    enum sc_motion_hold hold;  // motion only: button-gated or latched look mode
    // Dependency: the entry is active only while every condition holds.
    // ndeps == 0 means no dependency. A condition may read a key (a single
    // key or a combo), another mapping entry ("entry:<name>") or a built-in
    // feature flag ("flag:<name>").
    struct sc_mapping_cond deps[SC_COND_MAX_DEPS];
    int ndeps;
    int32_t pointer_id; // primary pointer id, 0 while unassigned (virtual = 0)
    bool down;         // trigger held (momentary) / logical state (toggle)
    bool active;       // injected press currently outstanding
    bool is_mouse;     // MOUSE_LEFT_LOCKED entry
};

struct sc_file_stamp {
    int64_t mtime_ns; // nanoseconds since epoch (or seconds*1e9 fallback)
    int64_t size;
    bool valid;
};

struct sc_mapping_manager {
    // Fixed table: no realloc, indices stay valid for the manager lifetime.
    struct sc_mapping_entry entries[SC_MAPPING_MAX_ENTRIES];
    int count; // number of occupied slots

    int mouse_right_idx;       // unused (MOUSE_RIGHT is a regular keycode now)
    int mouse_left_locked_idx; // -1 if the template has no such entry

    // Global state
    bool enabled;      // default false (a template must opt in)
    char *active_name; // current active template name (without .json)
    bool dirty;        // entries changed since the last successful save

    // Shortcuts (SDL keycodes)
    SDL_Keycode sc_switch;  // quick template switch (F2)
    SDL_Keycode sc_design;  // design mode (F3)
    SDL_Keycode sc_toggle;  // toggle mapping (F4)
    SDL_Keycode sc_manager; // built-in manager panel (F5)

    // File paths
    char *templates_dir; // .../templates/
    char *config_path;   // .../scrcpy_mapping_config.json

    // Hot-reload tracking (mtime + size, so sub-second edits are detected)
    struct sc_file_stamp active_stamp;
    struct sc_file_stamp config_stamp;

    // Pointer id allocator: monotonic decreasing, occupancy table, never
    // reuses an id that is still held. Avoids -1/-2/-3 (reserved by scrcpy).
    bool pid_used[SC_MAPPING_MAX_ENTRIES];
    int32_t pid_cursor;

    // Debounced template switch (mouse hover must not do file I/O)
    char *pending_switch;
    sc_tick pending_since;

    // Design mode: stage 0 = nothing, 1 = start point, 2 = start+end
    int design_stage;
    double design_nx;
    double design_ny;
    double design_dx;
    double design_dy;
    int design_duration_ms;
    int design_is_slide; // 0 = single-point touch, 1 = slide

    struct sc_mapping_load_stats last_load;

    // Called before every release-all (hot-reload, template switch, disable,
    // destroy): the owner must inject ACTION_UP for every held entry and stop
    // running slides, so that no finger stays stuck on the device.
    void (*release_hook)(void *userdata);
    void *release_opaque;
};

// ---- Lifecycle ----

bool
sc_mapping_manager_init(struct sc_mapping_manager *mm);

// Periodic work: debounced template switch + hot-reload. Safe to call from the
// event loop at a high rate.
void
sc_mapping_manager_tick(struct sc_mapping_manager *mm);

// Check for external file changes and reload if necessary.
void
sc_mapping_manager_reload_if_changed(struct sc_mapping_manager *mm);

// Release every held entry (through the release hook) and free resources.
void
sc_mapping_manager_destroy(struct sc_mapping_manager *mm);

// Register the release hook (must be set before any load/destroy).
void
sc_mapping_manager_set_release_hook(struct sc_mapping_manager *mm,
                                    void (*cb)(void *userdata),
                                    void *userdata);

// ---- Templates ----

// Switch the active template now (load first, then persist; on failure nothing
// changes). Returns false if the template could not be loaded.
bool
sc_mapping_manager_switch(struct sc_mapping_manager *mm, const char *name);

// Request a debounced switch (used by mouse hover: no file I/O here).
void
sc_mapping_manager_request_switch(struct sc_mapping_manager *mm,
                                  const char *name);

void
sc_mapping_manager_set_enabled(struct sc_mapping_manager *mm, bool enabled);

// List template names (without .json). Writes up to max pointers; caller frees
// each string. Returns the total number found.
int
sc_mapping_manager_list(struct sc_mapping_manager *mm, char **names, int max);

// ---- Entries ----

struct sc_mapping_entry *
sc_mapping_manager_find_single(struct sc_mapping_manager *mm, SDL_Keycode kc);

struct sc_mapping_entry *
sc_mapping_manager_find_by_name(struct sc_mapping_manager *mm,
                                const char *key_name);

bool
sc_mapping_manager_key_in_combo(struct sc_mapping_manager *mm, SDL_Keycode kc);

int
sc_mapping_manager_entry_count(struct sc_mapping_manager *mm);

// Add or update an entry (validated with the exact same rules as the JSON
// loader). Marks the template dirty on success.
bool
sc_mapping_manager_upsert(struct sc_mapping_manager *mm, const char *key_name,
                          enum sc_mapping_entry_type type, double nx, double ny,
                          double ndx, double ndy, int duration_ms,
                          char *err, size_t errlen);

// Full variant: also sets mode, dependency conditions and motion sensitivity.
// All the extra parameters are optional (NULL / 0 / ndeps == 0 keep the
// defaults). deps is an array of ndeps dependency conditions; every one of
// them must hold for the entry to be active.
// is_virtual creates a virtual key (no touch injection, state only).
bool
sc_mapping_manager_upsert_ex(struct sc_mapping_manager *mm, const char *key_name,
                             enum sc_mapping_entry_type type, double nx,
                             double ny, double ndx, double ndy, int duration_ms,
                             enum sc_mapping_mode mode,
                             const struct sc_mapping_cond *deps, int ndeps,
                             double sensitivity, enum sc_motion_hold hold,
                             bool is_virtual,
                             char *err, size_t errlen);

// True when some entry depends on this key (its state must be tracked even if
// the key itself is not mapped).
bool
sc_mapping_manager_key_is_dependency(struct sc_mapping_manager *mm,
                                     SDL_Keycode kc);

// Canonical name of a synthetic mouse-button keycode (NULL if not one).
const char *
sc_mapping_mouse_key_name(SDL_Keycode kc);

bool
sc_mapping_manager_remove_entry(struct sc_mapping_manager *mm,
                                const char *key_name);

// Save the active template if (and only if) it is dirty. Atomic replace.
bool
sc_mapping_manager_save_active(struct sc_mapping_manager *mm);

// Force a save even if not dirty (used by explicit "save" UI actions).
bool
sc_mapping_manager_save_active_force(struct sc_mapping_manager *mm);

// ---- Design mode ----

void
sc_mapping_manager_design_reset(struct sc_mapping_manager *mm);

// Record a clicked point (stage 1 = start, stage 2 = end of a slide).
void
sc_mapping_manager_design_click(struct sc_mapping_manager *mm,
                                double nx, double ny);

bool
sc_mapping_manager_design_has_point(struct sc_mapping_manager *mm);

// Bind the recorded point(s) to the given key name (touch when one point,
// slide when both points were recorded).
bool
sc_mapping_manager_design_bind(struct sc_mapping_manager *mm,
                               const char *key_name);

// ---- Key name helpers ----

SDL_Keycode
sc_mapping_parse_key_name(const char *name);

const char *
sc_mapping_key_name(SDL_Keycode kc);

// Validate a key expression ("a", "W+A", "MOUSE_RIGHT") with the same grammar
// as the loader. On failure, writes a reason into err.
bool
sc_mapping_validate_key_expr(const char *name, char *err, size_t errlen);

// Validate a dependency reference ("lshift", "entry:VIRT", "flag:look_mode").
// On failure, writes a reason into err.
bool
sc_mapping_validate_cond_ref(const char *expr, char *err, size_t errlen);

char *
sc_mapping_get_base_dir(void);

#endif
